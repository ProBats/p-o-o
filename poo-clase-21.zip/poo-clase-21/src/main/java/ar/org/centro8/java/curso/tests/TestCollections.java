package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class TestCollections {
    public static void main(String[] args) {
        System.out.println("** Interface List **");

        /*
         * La interface List representa una lista con indices, que emula a un Array.
         * List es la unica que tiene metodos definidos como indices.
         * De esta interfaz se pueden elegir distintas implementaciones con distintas tecnologias.
         * ArrayList es una lista tipo vector que tiene por dentro un comportamiento similar a 
         * un Array, pero que no es un Array, ya que es completamente dinamico
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente es una lista
         * enlazada.
         * La clase Vector tambien implementa List, no son los vectores que hemos visto anteriormente.
         * No se recomienda su uso, es una Tecnologia antigua. Tiene una sincronizacion excesiva, lo que
         * la hace demasiado lenta.
         * ArrayList es una lista tipo vector y LinkedList es una lista enlazada.
         * Hay una minima diferencia entre las dos y tiene que ver con la performance:
         * ArrayList es mas veloz para recorrer elementos
         * LinkedList es mas veloz para agregar y eliminar elementos
         */

         //Creo una referencia a la interfaz
        
        List lista;

        lista = new ArrayList<>();

        // .add() metodo para agregar elementos a un List
        lista.add(lista);
        lista.add(lista);
        //Esta lista no tiene especificado un tipo de dato particular
        //en ese caso queda definida como una lista de la clase Object, por lo tanto, dentro
        //puedo guardar cualquier elemento.
        lista.add("Hola");
        lista.add(83);
        lista.add(23.45);
        
        //recorrido por indices
        System.out.println("Recorrido por indices");
        for (int i = 0; i < lista.size(); i++) { // el metodo size indica la longitud de la lista
            System.out.println(lista.get(i));
            //con el metodo .get() obtengo el valor de la posicion de indice que pase como parametro
        }

        //Eliminar un elemento
        lista.remove(3); //Elimina el elemento del indice 3

        System.out.println("--- recorrido con for-each ---");
        for (Object l : lista) {
                System.out.println(l);
        }
        
        /*
         * Interface Iterable
         * Iterable es el padre de todas las interfaces del framework Collections.
         * Dentro de Iterable se encuentra definido el metodo foreach(), es un metodo default.
         * Este metodo realiza un recorrido sobre la lista. No realizamos nosotros una estructura 
         * repetitiva, si no que es la misma lista que se autorecorre.
         * Aparecio a partir del JDK 8.
         * El metodo foreach() estara presente para todas la colecciones. 
         */

        System.out.println("\n -- Recorrido con metodo foreach()\n");

        lista.forEach(item -> System.out.println(item));
        //el foreach() recibe como parametro una Lambda Expression.
        //en este caso item representa a cada elemento de la lista, luego con el operador flecha
        //le indico que para ese parametro (el elemento de la lista) realiza la o las acciones que
        //siguen. En este caso, la accion es imprimir por consola el mismo elemento que se recibio
        // como parametro.
        System.out.println("");
        //Si quisieramos definir mas de una sentencia tenemos que abrir llaves
        lista.forEach(item ->{
            System.out.println(item);
            System.out.println("Otra accion...");
        });

        System.out.println();

        //Referencia de metodos (Method references)
        System.out.println("Recorrido con foreach() simplificado");
        lista.forEach(System.out::println);
        //Si solo vamos a escribir una unica sentencia, podemos omitir el uso del parametro y la flecha
        //con el operador :: le estamos indicando a Java que el item implicito lo coloque como
        //argumento del metodo.
        //Esta es una sintaxis moderna, comoda, prolija y abreviada.

        System.out.println("\n** ListIterator **");
        /*
         * Es una interfaz especializada para recorrer colleciones que implementan List.
         * A diferencia del iterator simple (Iterator) o del metodo foreach() de Iterable, ListIterator
         * ofrece funcionalidades adicionales:
         *  - recorrido bidireccional: permite avanzar y retroceder sobre las listas.
         *  -tiene acceso a indices
         *  -permite eliminar, reemplazar y agregar elementos durante la iteracion. 
         */

        List nombres = new ArrayList<>();
        nombres.add("Ricardo");
        nombres.add("Jenny");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Marcelo");

        //Vamos a obtener el ListIterator de la lista
        ListIterator<String> li = nombres.listIterator();
        
        //Recorrido hacia adelante
        System.out.println("\n -- recorrido hacia adelante --");
        while (li.hasNext()) { // hasNext(). comprueba si queda un elemento  mas por recorrer en adelante
            int indice = li.nextIndex(); //nextIndext() devuelve el indice del elemento que se devolvera
            String nombre = li.next(); //next() devuelve el siguiente metodo
            System.out.println("Indice "+indice + ": " + nombre);
        }
        
    }
}
