package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.List;

public class TestCollections {
    public static void main(String[] args) {
        System.out.println("** Interface List **");

        /*
         * La interface List representa una lista con indices, que emula a un Array.
         * List es la unica que tiene metodos definidos como indices.
         * De esta interfaz se pueden elegir distintas implementaciones con distintas tecnologias.
         * ArrayList es una lista tipo vector que tiene por dentro un comportamiento similar a 
         * un Array, pero que no es un Array, ya que es completamente dinamico
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente es una lista
         * enlazada.
         * La clase Vector tambien implementa List, no son los vectores que hemos visto anteriormente.
         * No se recomienda su uso, es una Tecnologia antigua. Tiene una sincronizacion excesiva, lo que
         * la hace demasiado lenta.
         * ArrayList es una lista tipo vector y LinkedList es una lista enlazada.
         * Hay una minima diferencia entre las dos y tiene que ver con la performance:
         * ArrayList es mas veloz para recorrer elementos
         * LinkedList es mas veloz para agregar y eliminar elementos
         */

         //Creo una referencia a la interfaz
        
        List lista;

        lista = new ArrayList<>();

        // .add() metodo para agregar elementos a un List
        lista.add(lista);
        lista.add(lista);
    }
}
