package ar.org.centro8.java.curso.poo_clase_16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooClase16ApplicationTests {

	@Test
	void contextLoads() {
	}

}
