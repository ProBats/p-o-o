package ar.org.centro8.java.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.entities.Alumno;
import ar.org.centro8.java.curso.repositories.interfaces.IAlumnoDAO;

@Repository
public class AlumnoRepository implements IAlumnoDAO{

    //Creamos un objeto de DataSource que nos permite obtener la conexion a la base de datos
    //tomando una conexion del pool de conexiones que gestione HikariCP

    private final DataSource dataSource;
    //definimos otros atributos, van a ser estaticos para ahorrar memoria, y constantes para
    //garantizar que no se cambie la consulta en tiempo de ejecucion.
    //representan consultas sql
    private static String SQL_CREATE = "INSERT INTO alumnos(nombre,apellido,edad,idCurso,activo) VALUES (?,?,?,?,?)";
    //Los signos de pregunta son marcadores de posicion para los valores que se van a establecer
    private static final String SQL_FIND_BY_ID = "SELECT * FROM alumnos WHERE id = ?";
    private static final String SQL_FIND_ALL = "SELECT * FROM alumnos";
    private static final String SQL_UPDATE = "UPDATE alumnos SET nombre=?, edad=?, idCurso=?,activo?=? WHERE id=?";
    private static final String SQL_DELETE = "DELETE FROM alumnos WHERE id=?";
    private static final String SQL_FIND_BY_CURSO = "SELECT * FROM alumnos WHERE idCurso=?";

    public AlumnoRepository(DataSource dataSource){
        this.dataSource=dataSource;
    }

    //De esta manera, el repositorio queda configurado con la fuente de conexiones que se usara
    //siempre. El repositorio no crea su propio DataSource, si no que se le proporciona uno
    //configurado con HikariCP. Mantiene el diseño limpio y testeable, ya que se pueden crear
    //varias instancias con distintos tipos de DataSource, esto podría reprensentar distintas bases
    //como la de producción, desarrollo, testing, etc. Sin necesidad de tocar código interno

    @Override
    public void create(Alumno alumno) throws SQLException {
        try (Connection conn = dataSource.getConnection();//obtenemos la conexion
            PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS) //PreparedStatement es una interface de Java que representa una plantilla de consulta sql, sirve para ejecutar consultas SQL de forma segura y eficiente. Statement.RETURN_GENERETED_KEYS le indica a la base de datos que despues de ejecutar el insrt, debe devolver las claves generadas automaticamente(generalmente es el ID autoincrementable)
        ) {
            ps.setString(1, alumno.getNombre());    
            ps.setString(2, alumno.getApellido());    
            ps.setInt(3, alumno.getEdad());    
            ps.setInt(4, alumno.getIdCUrso());    
            ps.setBoolean(5, alumno.isActivo()); 
            ps.executeUpdate();// ejecuta la sentencia del insert.
            //para la sentencia que modifican datos (INSERT, UPDATE y DELETE) se utiliza executeUpdate()
            try (ResultSet keys = ps.getGeneratedKeys()) { //recupera las claves generadas
            // en este caso, seria el ID del nuevo registro de la tabla que la base devolvio
            //ResultSet es una interfaz de Java que representa un conjunto de resultados de una
            //consulta SQL. Como convencion se utiliza la palabra keys como nombre de variables porque
            //contiene las claves generadas
            //.getGeneratedKeys() se utiliza para recuperar el ResultSet que contiene cualquier clave
            //generada automaticamente por la base de datos.
                if (keys.next()) {
                    //mueve el cursor a la siguiente fila, si hay el menor una fila. Es decir, si se genera
                    //un id. Este metodo devuelve un booleano
                    alumno.setId(keys.getInt(1)); // le inserta el id al objeto de Alumno.
                    //recupera el valor entero de la primera columna del ResultSet de claves generadas.
                    //asumimos que en la primer columna estara el ID autoincremental;
                }
            }
        }
    }

    @Override
    public Alumno findById(int id) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Alumno> findAll() throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public int update(Alumno alumno) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public int delete(int id) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    @Override
    public List<Alumno> findByCurso(int idCurso) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByCurso'");
    }

}
