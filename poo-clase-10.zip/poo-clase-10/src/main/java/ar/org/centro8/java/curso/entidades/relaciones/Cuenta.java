package ar.org.centro8.java.curso.entidades.relaciones;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@RequiredArgsConstructor
@ToString
public class Cuenta {
    //al declarar la clase como final, indicamos que la misma no puede tener clases hijas
    //anulamos la herencia, en este caso por motivos de seguridad
    private final int nro;
    private final String moneda;
    //las declaramos final porque no queremos que se modifique el valor
    private float saldo;
    //eneste caso, el atributo no es final porque necesitamos que si cabie su valor
    //no esta incluido en el constructor, y su valor inicial es de 0.0 ya que los tipos de dato primitivos, no pueden ser nulos y tienen un proceso de inicializacion automatico

    public void depositar(float monto){
        this.saldo += monto;
    }

    public void debitar(float monto){
        if( this.saldo - monto < 0)System.out.println("no es posible descontar ese monto.");
        else this.saldo -= monto;
    }

}
