package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.arreglos.Auto;

public class TestArrays {
    public static void main(String[] args) {
        System.out.println("** Arrays o vectores **");
        /*
         * Un array es una estructura de datos en Java que permite almacenar Multiple valores
         * del mismo tipo de datos en una ubicacion continua de memoria.
         * Se utiliza cuando necesitamos manejar un conjunto fijo de elementos.
         */

        /*
          * tipoDeDato[] identificador; -> declaracion
          * tipoDeDato identificador[]; -> declaracion
          * identificador = new tipoDeDato[n]; -> cantidad de variables que va a tener 
          */

          //Creamo un arreglo de autos
        Auto[] autos;
        //solo se pueden guardar objetos del tipo Auto
        autos = new Auto[4];
        //la longitud del vector es de 4, es decir, que solo se podran guardar 4 objetos de Auto
        //Los vectores son estaticos, esto quiere decir que no lo puedo achicar ni guardar.
        //Si necesito otro tamaño de vector, lo tengo que eliminar y volver a crear.

        //Los vectores o arreglos tienen un proceso de inicializacion automatico

        //Los tipos de datos referenciados se inicializan null
        for (int i = 0; i < autos.length; i++) {
            System.out.println(autos[i]);
        }
        
        //los tipos de datos numericos se inicializan en 0
        int numeros[] = new int[4];
        for (int i = 0; i < autos.length; i++) {
            System.out.println(numeros[i]);
        }

        //Los tipos de datos char se inicializan con el caracter nulo '/u0000'
        int caracteres[] = new int[4];
        for (int i = 0; i < caracteres.length; i++) {
            System.out.println(caracteres[i]);
        }

        //asignacion de valores
        autos[0] = new Auto("Fiat","Palio","verde");
        //autos[1] = "hola"; no se puede guardar otro tipo de datos que no sea Auto
        autos[1] = new Auto("Volswagen","Gol","Gris");
        autos[2] = new Auto("Renault","Clio","Rojo");
        autos[3] = new Auto("Fiat","Uno","Blanco");
        autos[4] = new Auto("Ford","Taunus","Negro");



    }
}
