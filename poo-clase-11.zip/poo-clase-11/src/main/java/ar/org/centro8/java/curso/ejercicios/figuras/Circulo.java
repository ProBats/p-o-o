package ar.org.centro8.java.curso.ejercicios.figuras;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Circulo extends FiguraGeometrica{
    private double radio;

    @Override
    public double getPerimetro() {
        return 2 * Math.PI * radio;
    }

    @Override
    public double getSuperficie() {
        return Math.PI * Math.pow(radio, 2);
    }

}
