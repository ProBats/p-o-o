package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.java.curso.entidades.arreglos.Persona;

public class TestApiStream {
        public static void main(String[] args) {
        //Api Stream 
        /*
         * Permite procesar flujos de datos de manera uniforme, independientemente de la fuente
         * (archivo, BD, Web service, etc.), usando un enfoque declarativo con expresiones lambda.
         * API (Application Programing INterface): conjunto de metodos e interfaces que facilitan
         * el acceso a funcionalidades sin conocer su implementacion interna.
         * Una API podria decirse que es como un conjunto de reglas y herramientas que permite que
         * dos programas se comuniquen entre si.
         */

        List<Persona> personas = new ArrayList<>();

        //agregamos elementos a la lista
        personas.add(new Persona(1, "Ana", 32));
        personas.add(new Persona(2, "Javier", 42));
        personas.add(new Persona(3, "Carlos", 22));
        personas.add(new Persona(4, "Estela", 55));
        personas.add(new Persona(5, "Raul", 27));
        personas.add(new Persona(6, "Miguel", 37));
        personas.add(new Persona(7, "Monica", 47));
        personas.add(new Persona(8, "Marcela", 57));
        personas.add(new Persona(9, "Ricardo", 67));
        personas.add(new Persona(10, "Juan", 45));
        personas.add(new Persona(11, "Juan", 23));

        //Realizamos un paralelismo entre el codigo sql y API stream

        System.out.println("\n -- select * from personas;--");
        
        personas.forEach(System.out::println);

        //Steram provee metodos para poder filtrar
        //el metodo .stream() devuelve una implementacion de la interface Stream
        // el metodo .filter() permite sobreescribir un predicado de expresion lambda
        //un predicado es una interface funcional que define una condicion que un objeto determinado 
        //debe cumplir

        System.out.println("\n select * from personas where nombre = 'Ana';");
        personas
                .stream() // devuelve una secuencia de elementos para procesarlos (no los guarda)
                .filter(p -> p.getNombre().equals("Ana")) //Obtenemos un objeto del tipo Persona
                //Luego evaluamos con una expresion booleana
                //si el resultado es verdadero, el objeto formara parte de los resultados
                .forEach(System.out::println);

        System.out.println("\n -- select * from personas where nombre = 'Ana' or nombre = 'Juan'; ");
        personas
                .stream()
                .filter(p -> p.getNombre().equals("Ana") || p.getNombre().equals("Juan"))
                .forEach(System.out::println);

        System.out.println("\n -- select * from personas where nombre like 'ja%';");
        personas
                .stream()
                .filter(p -> p.getNombre().toLowerCase().startsWith("ja"))
                .forEach(System.out::println);

        System.out.println("\n -- select * from personas where nombre like '%a'; ");
        personas
                .stream()
                .filter(p -> p.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);

        System.out.println("\n select * from personas where nombre like '%ar%';");
        personas
                .stream()
                .filter(p -> p.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);

        System.out.println("\n -- select * from personas where edad >= 30; --");
        personas
                .stream()
                .filter(p -> p.getEdad() >= 30)
                .forEach(System.out::println);

        System.out.println("\n -- select * from personas where nombre = 'Juan' and edad >= 30; -- ");
        personas
                .stream()
                .filter(p -> p.getNombre().equals("Juan") && p.getEdad()>=30)
                .forEach(System.out::println);

        System.out.println("\n -- select * from personas order by nombre; --");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);
        //si solo llamamos al metodo sorted(), la clase Persona tendria que implementar la interfaz
        //Comparable, sobreescribiendo el metodo compareTo().
        //El metodo compareTo() es parte de la interfaz Comparable y se utiliza para definir el orden
        //natural de los objetos.
        //Eso no termina una solucion flexible, ya que si tuviesemos que cambiar el ordenamiento
        //deberiamos cambiar la implementacion del compareTo() y eso seria costoso.
        //La interfaz Comparator permite definir criterios de comparacion entre objetos, es decir,
        //especifica como se debe ordenar un conjunto de elementos. No se trata de ordenar segun el
        //orden natural de los objetos (como lo haria la interfaz Comparable) si no de definir un
        //criterio personalizado para compararlos

        System.out.println("\n -- select * from personas order by edad; --");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getEdad))
                .forEach(System.out::println);

        System.out.println("\n -- select * from personas order by nombre, edad; --");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre)
                        .thenComparing(Persona::getEdad))
                .forEach(System.out::println);
        //thenComparing() se usa para definir criterios de ordenamiento adicionales.

        System.out.println("\n -- select * from personas order by nombre desc, edad; --");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getEdad).reversed()
                        .thenComparing(Persona::getEdad))
                .forEach(System.out::println);

        System.out.println("\n -- select * from personas order by id; --");
        personas
                .stream()
                .sorted(Comparator.comparingInt(Persona::getId))
                .forEach(System.out::println);
        //comparingInt() trabaja la comparacion sobre numeros enteros.
        //Hace que se mejore la performance.

        System.out.println("\n -- select * from personas where edad between 30 and 40 order by nombre; --");
        personas
                .stream()
                .filter(p -> p.getEdad()>=30 && p.getEdad()<= 40)
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);

        System.out.println("\n -- select max(edad) from personas; --");
        int edadMaxima =personas
                                .stream()
                                .max(Comparator.comparingInt(Persona::getEdad))
                                .get()
                                .getEdad();
        System.out.println(edadMaxima);
        //el max devuelve un objeto de Optional, no devuelve una lista
        //contiene una persona con la mayor edad
        //con .get() obtenemos el valor del objeto Optional, o se, un objeto de la clase Persona
        //con .getEdad() obtenemos la edad del objeto Persona que vino del Optional.

        System.out.println("\n-- select * from where edad =(select max(edad) from personas); --");
        personas
                .stream()
                .filter(p -> p.getEdad() == (
                                                personas
                                                        .stream()
                                                        .max(Comparator.comparingInt(Persona::getEdad))
                                                        .get()
                                                        .getEdad()
                                                )
                        )  
                .forEach(System.out::println);

        //lo mas performace seria depender de una variable que almacena el valor de la edad maxima
        //ya que en este ejemplo, se estaria ejecutando una consulta dentro de otra por cada iteracion
        //en cada recorrido va a ir ejecutando nuevamente la consulta para obtener el mayor, con lo 
        //cual se vuelve muy lento
        //el siguinte ejemplo es mucho mas performante

        System.out.println("\n-- select * from personas where edad=(select max(edad) from personas); --");
        personas
                .stream()
                .filter(p -> p.getEdad() == edadMaxima)
                .forEach(System.out::println);
        
        }
}
