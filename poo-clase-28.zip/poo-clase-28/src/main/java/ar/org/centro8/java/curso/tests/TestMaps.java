package ar.org.centro8.java.curso.tests;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestMaps {
    public static void main(String[] args) {
        /*
         * Interface Map
         * La interfaz Map permite representar un diccionario o una estructura de datos de 
         * pares clave-valor. En un Map, cada clave (key) se asocia a un valor (value), y las
         * claves no tienen por que ser numeros ni consecutivas. Pueden ser de cualquier tipo de objeto
         * (por ejemplo String, Integer, etc.) Esto permite representar relaciones o
         * asociaciones en las que el indice es una clave arbitraria.
         * Un Map no extiende de Collection, aunque forma parte del framewok Collections, es una interfaz independiente
         * Cada clave es unica dentro del mapa, si se agrega un valor con una clave ya existente,
         * se reemplaza el valor anterior.
         * A partir del JDK 8, Map incorpora un metodo foreach que recibe un BiConsumer (una
         * expresion Lambda que acepta clave-valor) para recorrer de forma automatica todos sus pares de datos 
         */

        System.out.println("** Interfaz Map **");

        Map<String, String> mapaSemana;

        //El primer valor es la K (Key/llave) y el segundo es V (value/valor)
        //En este caso tomamos a la clase String como tipo de dato para la llave y el valor
        //no se pueden declarar ni llaves ni valores de tipos de datos primitivos, se deben
        //utilizar los wrappers

        //Implementaciones de Map

        //HashMap implementa un mapa sin ningun orden garantizado, es una de las implementaciones
        //mas eficientes  para operaciones de insercion y busqueda.
        mapaSemana = new HashMap<>();

        //LinkedHashMap: Mantiene el orden de insercion, lo que permite recorrer el mapa en el
        //orden que se agregaron los elementos
        mapaSemana= new LinkedHashMap<>();

        //TreeMap: Implementa NavigableMap que implementa SortedMap. Ordena las claves, segun 
        // su orden natural o mediante un Comparator. Para ello requiere que la clase de la clave
        // implemente la interfaz Comparable, similar a como funciona TreeSet
        mapaSemana = new TreeMap<>();

        //HashTable: es una clase Legacy (antigua) que implementa la interfaz Map, similar a HashMap
        //ya que su orden es aleatorio.
        //No esta deprecada, pero su uso no es recomendado en proyectos nuevos.
        //Sus metodos estan sincronizados, lo que la hace thread-safe, pero a costa de menor performance
        //Se mantiene para soporte a proyectos antiguos, pero en desarrollo moderno se prefiere utilizar
        //HashMap
        mapaSemana = new Hashtable<>();

        //con el metodo .put() agrego un elemento
        mapaSemana.put("lu","lunes");
        mapaSemana.put("ma","martes");
        mapaSemana.put("mi","miercoles");
        mapaSemana.put("ju","jueves");
        mapaSemana.put("vi","viernes");
        mapaSemana.put("sa","sabado");
        mapaSemana.put("do","domingo");
        //se pueden repetir los valores, pero no las llaves.

        //con el metodo .get() obtengo un elemento
        System.out.println(mapaSemana.get("lu"));

        System.out.println("\n -- recorrido de mapaSemana --");
        mapaSemana.forEach((k,v) -> System.out.println(k + " -> " + v));

        
    }
}
