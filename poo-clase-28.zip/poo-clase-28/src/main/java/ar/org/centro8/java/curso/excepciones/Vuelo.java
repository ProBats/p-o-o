package ar.org.centro8.java.curso.excepciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
public class Vuelo {
    private String nombreVuelo;
    private int cantidadDePasajes;

    public synchronized void venderPasajes( int cantidad) throws NoHayMasPasajesException{
        if (cantidad > cantidadDePasajes) throw new NoHayMasPasajesException(nombreVuelo,cantidadDePasajes,cantidad);
        cantidadDePasajes-= cantidad;
    }
    /*
     * La clausula throws se utiliza la firma de un metodo para indicar que este podria lanzar
     * (throw) una o mas excepciones que no se manejan internamente. Es decir, se declara la 
     * posibilidad de que se produzca una excepcion para que el codigo que llame a ese metodo sea
     * consciente de ello y decida como manejarla (ya sea capturandola mediante un try-catch o 
     * propagandola a su vez).
     * En Java, las checked exceptions deben ser gestionadas. Si un metodo puede lanzar una
     * excepcion verificada y no la maneja dentro de un bloque try-catch, es obligatorio declararlo
     * con throws para que el compilador sepa quien invoque el metodo, debe encargarse del manejo
     * de la excepcion.
     */

    /* 
     * En una situacion real de venta de pasajes, por ejemplo, se utiliza la clausula syncronized
     * El modificador syncronized se utiliza en Java para garantizar que solo un hilo a la vez
     * pueda ejecutar un bloque de codigo o un metodo que accede a recursos compartido.
     * Esto garantiza la integridad de los datos. 
    */
    
}
