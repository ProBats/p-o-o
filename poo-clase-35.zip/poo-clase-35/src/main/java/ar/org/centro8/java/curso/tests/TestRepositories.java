package ar.org.centro8.java.curso.tests;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.java.curso.entities.Alumno;
import ar.org.centro8.java.curso.entities.Curso;
import ar.org.centro8.java.curso.entities.enums.Dia;
import ar.org.centro8.java.curso.entities.enums.Turno;
import ar.org.centro8.java.curso.repositories.AlumnoRepository;
import ar.org.centro8.java.curso.repositories.CursoRepository;
import ar.org.centro8.java.curso.repositories.interfaces.IAlumnoDAO;
import ar.org.centro8.java.curso.repositories.interfaces.ICursoDAO;

/*Esta clase utilizara el contexto de Spring Boot para obtener los DAOs y ejecutar operaciones
 * Esta clase no es parte de la logica de negocio de la aplicacion en si mismo, sino una herramienta
 * para probar manualmente que nuestras capas de entidades y acceso a datos funcionan correctamente
 * Es un entorno de pruebas, ya que antes de construir una interfaz grafica, necesitamos estas
 * seguros de que los metodos (create, delete, update, findAll,fin by...) interactuan bien con 
 * la base de datos
 * Es una aplicacion real con GUI, se inyectarian servicios y controladores.
 */

/*
  * Con esta anotacion le estamos diciendo a Spring que inicie la aplicacion escaneando todos
  * los componentes en el paquete principal. Spring se va a encargar de crear y configurar 
  * todas las piezas de la aplicacion (DataSouce, DAO, etc.)
  */
@SpringBootApplication(scanBasePackages = "ar.org.centro8.java.curso" )
public class TestRepositories {
    public static void main(String[] args) {
        //iniciar el contexto de Spring Boot
        //ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);
        //Esto levanta toda la configuracion incluyendo el DataSource y los DAOs
        //el metodo .run() devuelve el contexto de la aplicacion
        //SpringApplication.run(TestRepositories.class, args) esta linea es la que arranca la aplicacion
        //Si Spring.sql.init.mode= always, Spring Boot va a ejecutar los archivos de schema_DDL.sql
        //y data_DML.sql limpiando y repoblando la base nuevamente.

        System.out.println("*** Pruebas manuales de acceso a datos ***");
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args)) {
            //obtenemos la instacias de los repositorios
            IAlumnoDAO alumnoDAO = context.getBean(AlumnoRepository.class);
            ICursoDAO cursoDAO = context.getBean(CursoRepository.class);

            //PRUEBAS PARA ALUMNOS

            //TEST 1: Crear un alumno nuevo
            System.out.println("\n>>> Test1: Creando un nuevo alumno...");
            Alumno nuevoAlumno = new Alumno(0,"Ricardo","Iorio",63,1,true);
            alumnoDAO.create(nuevoAlumno); //El ID se le asigna dentro del metodo create()
            if (nuevoAlumno.getId()>0) {
                System.out.println("    Alumno creado con ID: " + nuevoAlumno.getId());
                System.out.println(nuevoAlumno);
            } else {
                System.out.println("ERROR: no se pudo crear el alumno...");
            }

            //TEST 2: Buscar un alumno por ID (existente)
            System.out.println("\n>>> Test2: buscando alumno por ID " + nuevoAlumno.getId() + "...");
            Alumno alumnoEncontrado = alumnoDAO.findById(nuevoAlumno.getId());
            if (alumnoEncontrado != null) {
                System.out.println("    Alumno encontrado: " + alumnoEncontrado);
            } else {
                System.out.println("ERROR: no se encontro el alumno con ID: " + nuevoAlumno.getId());
            }

            //TEST 3: Buscar un alumno por ID(inexistente)
            System.out.println("\n>>>Test3: buscando alumno por ID 999...");
            Alumno alumnoNoEncontrado = alumnoDAO.findById(999);
            if (alumnoNoEncontrado != null) {
                System.out.println("Alumno encontrado: " + alumnoEncontrado);
            } else{
                System.out.println("ERROR: No se encontro el alumno con ID 999");
            }

            //TEST 4: Actualizar un alumno
            System.out.println("\n>>> Test4: actualizando alumno por ID " + nuevoAlumno.getId() + "...");
            alumnoEncontrado.setNombre("Ricardo Horacio"); //le cambiamos el nombre en la base
            alumnoEncontrado.setIdCUrso(2);
            int filaAfectadas = alumnoDAO.update(alumnoEncontrado);
            if (filaAfectadas==1) {
                System.out.println("    Alumno: " + alumnoEncontrado.getId() + " acutalizado correctamente...");
            } else {
                System.out.println("ERROR: no se pudo actualizar al alumno");
            }

            //TEST 5: Listar todos los alumnos
            System.out.println("\n>>> Listando todos los alumnos...");
            List<Alumno> alumnos = alumnoDAO.findAll();
            if (!alumnos.isEmpty()) {
                System.out.println("Alumnos encontrados: " + alumnos.size());
                alumnos.forEach(System.out::println); 
            } else {
                System.out.println("ERROR: No se encontraron alumnos.");
            }

            //TEST 6: Eliminar un alumno
            System.out.println("\n>>> Test6: Eliminando un alumno de id: " + nuevoAlumno.getId() + "...");
            filaAfectadas = alumnoDAO.delete(nuevoAlumno.getId());
            if (filaAfectadas == 1) {
                System.out.println("Alumno de id: " + nuevoAlumno.getId() + " eliminado correctamente.");
                System.out.println("Verificando eliminacion -> " + alumnoDAO.findById(nuevoAlumno.getId()));
            } else {
                System.out.println("ERROR: no se pudo al alumno.");
            }

            //TEST 7: Eliminar un alumno 999
            System.out.println("\n>>> Test6: Eliminando un alumno de id: 999...");
            filaAfectadas = alumnoDAO.delete(999);
            if (filaAfectadas == 1) {
                System.out.println("Alumno de id: " + nuevoAlumno.getId() + " eliminado correctamente.");
                System.out.println("Verificando eliminacion -> " + alumnoDAO.findById(999));
            } else {
                System.out.println("ERROR: no se pudo al alumno.");
            }

            //Pruebas para CURSO
            System.out.println("\n Pruebas de Curso");

            // TEST 8: Crear un nuevo curso
            System.out.println("\n>>> Test8: Creando un nuevo curso.");
            Curso nuevoCurso = new Curso(1,"JAVA Avanzado","Francisco Acuña", Dia.LUNES,Turno.MAÑANA,true);

            cursoDAO.create(nuevoCurso);
            if (nuevoCurso.getId() > 0) {
                System.out.println("    Curso creado con ID: " + nuevoCurso.getId());
                System.out.println(nuevoCurso);
            } else {
                System.out.println("ERROR: no se pudo crear el curso...");
            }

            // TEST 9: Buscar un curso por ID (existente)
            System.out.println("\n>>> Test9: Buscando un curso por id: "+ nuevoCurso.getId());
            Curso cursoEncontrado = cursoDAO.findById(nuevoCurso.getId());
            if (cursoEncontrado != null) {
                System.out.println("Curso encontrado: " + cursoEncontrado);
            } else {
                System.out.println("ERROR: No se encontro el curso con ID: " + nuevoCurso.getId());
            }

            // TEST 10: Buscar un curso por ID (inexistente)
            System.out.println("\n>>> Test10: Buscando un curso por id: 999");
            Curso cursoNoEncontrado = cursoDAO.findById(999);
            if (cursoEncontrado != null) {
                System.out.println("Curso encontrado: " + cursoEncontrado);
            } else {
                System.out.println("ERROR: No se encontro el curso con ID: " + nuevoCurso.getId());
            }

            //TEST 11: Listar todos los cursos
            System.out.println("\n>>> Test10: Listando todos los cursos...");
            List<Curso> cursos = cursoDAO.findAll();
            if (!cursos.isEmpty()) {
                System.out.println("Cursos encontrados: "+ cursos.size());
                cursos.forEach(System.out::println);
            } else{
                System.out.println("EROR: No se encontraron cursos.");
            }

            //TEST 12: Actualizar un curso
            System.out.println("\n>>> Test12: Actualizando curso de ID: " + nuevoCurso.getId() + "...");
            nuevoCurso.setProfesor("Rob Haldford");
            nuevoCurso.setTitulo("JAVA para principiantes");
            filaAfectadas= cursoDAO.update(nuevoCurso);
            if (filaAfectadas > 0) {
                System.out.println("Curso: " + nuevoCurso.getId() + " actualizado correctamente.");
            } else {
                
            }

            //TEST 11: Buscar cursos por Dia y Turno
            System.out.println("\n>>> Test11: buscando cursos de LUNES por MAÑANA...");
            cursos
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("ERROR en la base de datos durante las pruebas!!");
        } finally {
            System.out.println();
        }
    }
}
