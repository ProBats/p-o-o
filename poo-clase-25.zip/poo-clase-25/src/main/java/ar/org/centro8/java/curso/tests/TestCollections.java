package ar.org.centro8.java.curso.tests;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

import ar.org.centro8.java.curso.entidades.arreglos.Auto;

public class TestCollections {
    public static void main(String[] args) {
        System.out.println("** Interface List **");

        /*
         * La interface List representa una lista con indices, que emula a un Array.
         * List es la unica que tiene metodos definidos como indices.
         * De esta interfaz se pueden elegir distintas implementaciones con distintas tecnologias.
         * ArrayList es una lista tipo vector que tiene por dentro un comportamiento similar a 
         * un Array, pero que no es un Array, ya que es completamente dinamico
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente es una lista
         * enlazada.
         * La clase Vector tambien implementa List, no son los vectores que hemos visto anteriormente.
         * No se recomienda su uso, es una Tecnologia antigua. Tiene una sincronizacion excesiva, lo que
         * la hace demasiado lenta.
         * ArrayList es una lista tipo vector y LinkedList es una lista enlazada.
         * Hay una minima diferencia entre las dos y tiene que ver con la performance:
         * ArrayList es mas veloz para recorrer elementos
         * LinkedList es mas veloz para agregar y eliminar elementos
         */

         //Creo una referencia a la interfaz
        
        List lista;

        lista = new ArrayList<>();

        // .add() metodo para agregar elementos a un List
        lista.add(new Auto("Peugeot", "388", "Negro"));
        lista.add(new Auto("Chevrolet","Corsa","Rojo"));
        //Esta lista no tiene especificado un tipo de dato particular
        //en ese caso queda definida como una lista de la clase Object, por lo tanto, dentro
        //puedo guardar cualquier elemento.
        lista.add("Hola");
        lista.add(83);
        lista.add(23.45);
        
        //recorrido por indices
        System.out.println("Recorrido por indices");
        for (int i = 0; i < lista.size(); i++) { // el metodo size indica la longitud de la lista
            System.out.println(lista.get(i));
            //con el metodo .get() obtengo el valor de la posicion de indice que pase como parametro
        }

        //Eliminar un elemento
        lista.remove(3); //Elimina el elemento del indice 3

        System.out.println("--- recorrido con for-each ---");
        for (Object l : lista) {
                System.out.println(l);
        }
        
        /*
         * Interface Iterable
         * Iterable es el padre de todas las interfaces del framework Collections.
         * Dentro de Iterable se encuentra definido el metodo foreach(), es un metodo default.
         * Este metodo realiza un recorrido sobre la lista. No realizamos nosotros una estructura 
         * repetitiva, si no que es la misma lista que se autorecorre.
         * Aparecio a partir del JDK 8.
         * El metodo foreach() estara presente para todas la colecciones. 
         */

        System.out.println("\n -- Recorrido con metodo foreach()\n");

        lista.forEach(item -> System.out.println(item));
        //el foreach() recibe como parametro una Lambda Expression.
        //en este caso item representa a cada elemento de la lista, luego con el operador flecha
        //le indico que para ese parametro (el elemento de la lista) realiza la o las acciones que
        //siguen. En este caso, la accion es imprimir por consola el mismo elemento que se recibio
        // como parametro.
        System.out.println("");
        //Si quisieramos definir mas de una sentencia tenemos que abrir llaves
        lista.forEach(item ->{
            System.out.println(item);
            System.out.println("Otra accion...");
        });

        System.out.println();

        //Referencia de metodos (Method references)
        System.out.println("Recorrido con foreach() simplificado");
        lista.forEach(System.out::println);
        //Si solo vamos a escribir una unica sentencia, podemos omitir el uso del parametro y la flecha
        //con el operador :: le estamos indicando a Java que el item implicito lo coloque como
        //argumento del metodo.
        //Esta es una sintaxis moderna, comoda, prolija y abreviada.

        System.out.println("\n** ListIterator **");
        /*
         * Es una interfaz especializada para recorrer colleciones que implementan List.
         * A diferencia del iterator simple (Iterator) o del metodo foreach() de Iterable, ListIterator
         * ofrece funcionalidades adicionales:
         *  - recorrido bidireccional: permite avanzar y retroceder sobre las listas.
         *  -tiene acceso a indices
         *  -permite eliminar, reemplazar y agregar elementos durante la iteracion. 
         */

        List nombres = new ArrayList<>();
        nombres.add("Ricardo");
        nombres.add("Jenny");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Marcelo");

        //Vamos a obtener el ListIterator de la lista
        ListIterator<String> li = nombres.listIterator();
        
        //Recorrido hacia adelante
        System.out.println("\n -- recorrido hacia adelante --");
        while (li.hasNext()) { // hasNext(). comprueba si queda un elemento  mas por recorrer en adelante
            int indice = li.nextIndex(); //nextIndext() devuelve el indice del elemento que se devolvera
            String nombre = li.next(); //next() devuelve el siguiente metodo
            System.out.println("Indice "+indice + ": " + nombre);
        }

        //Recorrido hacia atras
        System.out.println("\n -- Recorrido hacia atras -- ");
        
        while (li.hasPrevious()) {
            int indice = li.previousIndex();
            String nombre = li.previous();
            System.out.println("Indice "+indice + ": " + nombre);
            
        }
        
        //Reemplazar elementos
        while (li.hasNext()) { 
            String nombre = li.next(); 
            if (nombre.toLowerCase().equals("carlos")) li.set("david"); // reemplazar el nombre de carlos, por David
        }
        System.out.println("\nLista despues de reemplazar a Carlos por David:" + nombres);


        //reinicio la posicion del puntero del ListIterator

        li = nombres.listIterator();

        //agregar elementos
        while (li.hasNext()) {
            String nombre = li.next();
            if (nombre.equals("Ana")) li.add("Juan"); //Agrega a Juan despues de Ana
        }
        System.out.println("\n Lista despues de agregar a Juan luego de Ana: " + nombres);

        //Eliminar elementos

        while (li.hasPrevious()) {
            String nombre = li.previous();
            if (nombre.equals("Jenny")) li.remove(); // Elimina el elemento actual
        }
        System.out.println("\n Lista despues de eliminar el elemento 'Jenny': " + nombres);

        //Generics
        /*
         * Para especificar el tipo de dato de una coleeccion lo hacemos a traves de una generics.
         * Los generics aparecieron a partir del JDK 5 y son una caracteristica que permite crear
         * clases, interfaces o metodos con tipos de datos parametrizados
         * Esto significa que podemos definir estructuras de datos y metodos que funcionen con 
         * cualquier tipo de dato, pero manteniendo la seguridad de tipos en tiempo de compilacion.
         * Los Generics permiten que una clase  o metodo trabaje con diferentes tipos de datos sin
         * tener que escribir varias versiones del mismo codigo.
         */

        List<Auto> listaAuto = new ArrayList<>();
        //No se pueden crear colecciones de tipos de datos primitivos, es decir, no se pueden 
        // poner  tipos de datos primitivos  en  los Generics, para eso se utilizan los wrappers
        // int -> Integer, double -> Double, float -> Float, char -> Character, boolean -> Boolean

        listaAuto.add(new Auto("Renault", "Clio", "Verde Fuego"));
        // lista.Auto.add("Hola"); ERROR, no puedo agreagr otro tipo de dato a la lista.

        //si quiero asignar a una variable del tipo Auto un elemento de la lista de Object, que 
        //sea un Auto, la voy a tener de castear primero.

        Auto auto1 = (Auto) listaAuto.get(0);

        //Si asignamos un elemento de listaAuto no hace falta castear, porque la lista ya es del tipo Auto

        Auto auto2 = listaAuto.get(0);

        //copiar los autos de lista a listaAuto
        //para copiar, tenemos que tener en cuenta que no todos los elementos de la lista son autos.
        lista.forEach(item -> {
            if (item instanceof Auto) {
                listaAuto.add((Auto) item); 
            }
        });

        System.out.println("\n Recorrido de la listaAuto");
        listaAuto.forEach(System.out::println);

        ///////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("\n $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ \n");

        System.out.println("\n ** Interface Set ** ");
        /*
         * La interface Set implementa Collection y tiene 3 implementaciones.
         * La interfaz Set provee una lista sin indices. El mismo objeto contenido en la lista
         * es el indice. Por esa misma razon, no se admiten valores duplicados.
         */

         //HashSet
        // La implementacion HashSet es la mas veloz de todas las implementaciones de Set-
        Set<String> setSemana;
        setSemana = new HashSet<>();
        setSemana = new LinkedHashSet<>();
        setSemana = new TreeSet<>();

        //Agregamos elementos al set
        setSemana.add("Lunes");
        setSemana.add("Martes");
        setSemana.add("Miercoles");
        setSemana.add("Jueves");
        setSemana.add("Viernes");
        setSemana.add("Sabado");
        setSemana.add("Domingo");
        
        //no podemos hacer un recorrido por indices, justamente porque no tiene  indices.
        //Podemos saber la longitud, pero no tiene indices
        System.out.println("\n Recorrido del set");
        setSemana.forEach(System.out::println);
        //HashSet no brinda un ordenamiento especifico. Lo recorre de la manera mas rapida posible.

        //LinkedHashSet
        /*
         * Es otra implementacion de Set. Por lo tanto, no permite valores duplicados y no hay indices
         * No es rapida como HashSet, auntque ese comportamiento no se va a notar en proyectos chicos
         * Almacena los elementos en una lista enlazada, esto quiere decir que cuando recorremos la lista
         * vamos a ver los elementos por orden de entrada
         */

         //TreeSet
        /*
         * La clase TreeSet implementa SortedSet, que extiende de Set.
         * Al usar TreeSet, la clase del Generic debe implementar la interfaz Comparable.
         * Es una implementacion que almacena en un arbol de orden natural
         * Esto quiere decir que los elementos van a aparecer ordenados. En este caso, al ser
         * elementos del tipo String, el ordenamiento va a ser alfabetico.
         * No necesitamos un codigo de ordenamiento especifico
         */

         //Creamos un Set de Auto
        Set<Auto> setAutos;
        //setAutos = new HashSet<>();
        //setAutos = new LinkedHashSet<>();
        setAutos = new TreeSet<>();

        //agregamos los autos de listaAuto a setAutos
        //lo recorremos con foreach y agregamos con expresion lambda
        listaAuto.forEach(setAutos::add);
        listaAuto.forEach(auto -> setAutos.add(auto));
        //Esta seria la forma mas larga de la misma sentencia.
        //tambien podemos utilizar el metodo definido en la interfaz Collections, addAll()
        setAutos.addAll(listaAuto);


        System.out.println("\n -- recorrido de setAutos --");
        setAutos.forEach(System.out::println);

        setAutos.add(new Auto("Chevrolet","Corsa","Rojo"));
        setAutos.add(new Auto("Chevrolet","Corsa","Rojo"));

        System.out.println("\n -- Recorrido de SetAutos --");
        setAutos.forEach(auto -> System.out.println(auto + "\t" + auto.hashCode()));

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("\n $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ \n");

        System.out.println("\n ** Interface Queue ** ");

        /*
         * Implementaciones comunes de Queue:
         * 
         * - ArrayDeque: 
         *  Es una implementacion eficiente para colas estandard donde se encolan elementos en la 
         * parte de atras y se desencolan desde la parte de adelante.
         * 
         * -PriorityDeque
         * Organiza los elementos basandose en su orden natural o mediante un Comparator, lo que
         * permite manejar prioridades, en este caso, el orden de extraccion puede no coincidir con
         * el orden de insercion.
         * 
         * -LinkedList:
         * Tambien implementa Queue (a traves de la interface Deque), y puede usarse para representar 
         * una cola, auque ArrayDeque suele ser preferida por su rendimiento.
         * 
         * Las colas estan diseñadas para procesar elementos en un cierto orden (usualmente es el FIFO -
         * First In First Out). Una vez que el elemento ha sido procesado o ya no es necesario en el 
         * contexto de la cola, se desencola para que la cola pueda avanzar y atender al siguiente elemento.
         * 
         * Conceptos clave:
         * - Encolar: insertar un elemento en la parte trasera de la cola.
         * - Desencolar: eliminar el elemento que se encuentra en la parte delantera de la cola.
         * - FIFO: el primer elemento en entrar es el primero en salir, lo que garantiza un procesamiento
         * en orden de llegada 
         * 
         */

         //creamos un referencia a la interfaz
        Queue<Auto> colaAutos;

        colaAutos = new ArrayDeque<>();

        //el metodo .offer() permite encolar un elemento.
        colaAutos.offer(auto1);
        colaAutos.offer(auto2);
        colaAutos.offer(new Auto("Ford", "Focus", "Naranja fosforescente"));
        //tambien existe el metodo .add() para agregar, las diferencias es como trabajan internamente.
        //El metodo .add si la coleccion del tipo cola esta completa, lanza una excepcion.
        //El metodo .offer(), en cambio, devuelve un valor booleano que dara false si no se pudo guardar
        //elemento, sin lanzar una excepcion.

        //Hay clases que implementan la interface Queue y representan estructuras de datos con una
        //capacidad limitada.
        //ArrayBlockingQueue y LinkedBlockingQueue del paquete java.util.concurrent son muy comunes
        //en aplicaciones concurrentes o en sistemas donde se deseae limitar el uso de la memoria.

        //para agregar mas de una sola vez
        colaAutos.addAll(listaAuto);

        System.out.println("\n -- recorrido de colaAutos --");
        colaAutos.forEach(System.out::println);

        //El metodo .size() permite obtener la longitud de la coleccion
        System.out.println("\n -- Longitud de la cola: --" + colaAutos.size());

        //desencolamos elementos, lo hace desde el primero hacia el ultimo
        //el metodo .poll() desencola elementos, los recupera y los elimina.
        System.out.println("\n -- eliminando elementos --");
        while (!colaAutos.isEmpty()) {
            System.out.println(colaAutos.poll());
        }

        //el metodo .remove() hace lo mismo pero si la cola esta vacia, lanza una excepcion 
        //.poll() devuelve null

        //PriorityQueue
        /*
         * Permite almacenar elementos de forma que el elemento con mayor prioridad ( segun el 
         * orden natural o un Comparator definido) siempre se encuentre en la cabeza de la cola.
         * La prioridad se define ya sea mediante el orden natural de los elementos (por ejemplo,
         * si implementan COmparable) o mediante un objeto del tipo COmparator que se pase como
         * parametro al momento de la creacion.
         * En su implementacion interna, garantiza que el primer elemento sea siempre el de menor valor 
         * o mayor prioridad, segun el criterio definido. Pero el resto de la estructura no se encuentra
         * completamente ordenada. Solo garantiza el orden relatico de la cabeza.
         * Al encolar elementos, reorganiza internamente su estructura para mantener la prioridad de que 
         * el menor elemento o el de mayor prioridad, este en la raiz.
         * Al iterar sobre una PriorityQueue (por ejemplo con un recorrido foreach), el orden en el que
         * se recorren los elementos, no es necesariamente el orden natural o el orden de prioridades. El
         * iterador recorre el arreglo que no esta completamente ordenado.
         */
        
         System.out.println("\n ** Clase Stack ** ");

        /*
         * La clase Stack representa una pila en Java.
         * Es una clase, no una interfaz y hereda de Vector.
         * Vector es una clase historica de Java que implementa un vector o arreglo dinamico de 
         * dimension extensible mediante la incorporacion de nuevos elementos, Aunque en versiones
         * mas recientes, se refiere utilizar ArrayList para vectores, la clase vector sigue estando
         * vigente.
         * Stack es una lista con indices.
         * Stack implementa la funcionalidad de una pila, lo que significa que utiliza el concepto de 
         * LIFO (Last In First Out): el ultimo en entrar es el primero en salir.
         * Aunque la clase Stack sigue estando vigente, en el desarrollo moderno se comienda utilizar
         * implementaciones de Deque como ArrayDeque para representar pilas, ya que ofrece mayor eficiencia
         */

        Stack<Auto> pilaAutos = new Stack<>();

        //El metodo .push agrega un elemento al tope de la pila (apilar)
        pilaAutos.push(new Auto("Citroen", "C5","verde"));

        //agregar toda una coleccion
        pilaAutos.addAll(listaAuto);

        System.out.println("\n -- recorrido de pilaAutos -- ");
        pilaAutos.forEach(System.out::println);

        System.out.println("\nLongitud de la pila " + pilaAutos.size());

        System.out.println("\n Eliminar elementos de una pila: ");
        //el metodo .pop() elimina elmentos de una pila (desapilar)
        while (!pilaAutos.isEmpty()) {
            System.out.println("Elemento eliminado -> " + pilaAutos.pop());
        }

        System.out.println("\n Longitud de la pila: " + pilaAutos.size());

    }
}
