package ar.org.centro8.java.curso.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class EmpleadoComposicion {
    //Las composiciones son de las relaciones mas fuertes entre clases
    //una clase no tiene sentido sin la instancia de la otra clase que la compone
    // la reconocemos con las palabras "siempre tiene un/a"
    //en este caso, un empleado siempre tiene un auto

    private int legajo;
    private String nombre;
    private String apellido;
    @NonNull //Es una anotacion de lombok que indica que el valor no puede ser  nulo
    private Auto auto;

    //Si quisiera ingresar un auto nulo, va a dar error en tiempo de ejecucion
    //de esta manera nos aseguramos que un empleado siempre tenga un auto.
   
    //un ejemplo de una relacion de composicion mas fuerte, se podria dar cuanto al crear
    //el objeto de la clase EmpleadoComposicion,creemos un nuevo Objeto del tipo auto en ese momento
     
    public EmpleadoComposicion(int legajo, String nombre, String apellido, String marca,String modelo, String color) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.auto = new Auto(marca, modelo, color);
    }

    //No podemos crear un objeto de EmpleadoComposicion sin asignarle el auto.
    //Tambien podriamos g¿hacer que el setAuto() le asigne un nuevo auto en vez de una existente

    public void setAuto(String marca, String modelo, String color){
        this.auto = new Auto(marca, modelo, color);
    }
}
