package ar.org.centro8.java.curso.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmpleadoAsociacionSimple {
//la Asociacion Simple en la relacion menos acoplada
//la reconocemos por las palabras "usa un/a"
//por ejemplo, en este caso, un empleado usa un Auto

private int legajo;
private String nombre;
private String apellido;

public void usaAuto(Auto auto){
    System.out.println("El empleado "+this.nombre + " "+ this.apellido + " esta utilizando el auto " + auto);
}
}
