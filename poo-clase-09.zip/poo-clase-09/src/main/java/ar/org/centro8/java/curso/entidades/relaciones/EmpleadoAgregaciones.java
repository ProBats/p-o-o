package ar.org.centro8.java.curso.entidades.relaciones;

import lombok.Data;

@Data
public class EmpleadoAgregaciones {
    //Las agregaciones son un tipo de relacion un poco mas fuerte entre clases
    //son de las mas utilizadas "tiene un/a"
    //por ejemplo en este caso, un empleado tiene un Auto
    
    private int legajo;
    private String nombre;
    private String apellido;
    private Auto auto;

    public EmpleadoAgregaciones(int legajo, String nombre, String apellido) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
    } 
    //Creamos el constructor sin el auto, ya que puede ser opcional en un principio
    //con el set de auto, le asignamos el auto al empleado y tambien lo podemos cambiar
    
}
