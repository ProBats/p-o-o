package ar.org.centro8.java.curso.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import ar.org.centro8.java.curso.models.entities.Alumno;
import ar.org.centro8.java.curso.models.repositories.interfaces.IAlumnoRepository;

/*
 * Para este proyecto decidimos agregar una capa adicional al modelo clasico de MVC, la capa de 
 * servicios. Esta estructura es muy utilizada hoy en dia porque sigue el principio de separacion 
 * de responsabilidades, lo cual mejora la organizacion y mantenibilidad del codigo.
 * La capa de modelo (model) se encarga exclusivamente de representar los datos y gestionar el
 * acceso a la base de datos.
 * La capa de vista (view) se enfoca en la interaccion con el usuario, muestra la informacion.
 * El controlador (controller) solo recibe las solicitudes, prepara los datos para la vista y
 * delega las decisiones importantes.
 * La capa de servicio (service) es la encargada de aplicar las reglas de negocio: validaciones,
 * calculos verificaciones, etc.
 * Asi cada parte del sistema cumple con una funcion especifica, evitando que se mezclen responsabilidades
 * y permitiendo que el sistema escale o cambie finalmente en el futuro.
 */

/**
  * Clase de servicio para la entidad Alumno.
  * Encapsula la logica e negocio relacionada con los alumnos.
  * Actua como intermediario entre los controladores y los repositorios, asegurando que los
  * controladores sean "delegados" y que la logica de negocio sea reutilizable y testeable en forma 
  * aislada.
  */
@Service //indica a Spring que esta clase es un componente de servicio, manejando el contenedor de Spring
public class AlumnoService {

    private final IAlumnoRepository alumnoRepository;

    //inyeccion de dependencias del repositorio de Alumno
    //el servicio necesita interactuar con la capa de persistencia para acceder a los datos
    //en el constructor Spring provee automaticamente un instancia de IAlumnoDAO
    public AlumnoService(IAlumnoRepository alumnoRepository){
        this.alumnoRepository = alumnoRepository;
    }

    /**
     * Obtiene una lista de todos los alumnos.
     * Aqui se vuelva la logica de negocio adicional antes o despues de la llamada al repositorio.
     * @return -> lista de objetos de la clase Alumno
     * @throws SQLException -> puede lanzar una excepcion al acceder a la DB
     */
    public List<Alumno> obtenerTodosLosAlumnos() throws SQLException{
        return alumnoRepository.findAll();
        //esta logica es simple, solo delega al repositorio la obtencion de la lista .
        //aqui se podrian poner la calidaciones, como por ejemplo validar que usuario lo pide.
        //se pueden transformar los datos antes de mostrar.
    }

    /**
     * Guardar un nuevo alumno o actualiza uno existente.
     * Este metodo encapsula la logica de persistir un alumno
     * @param alumno alumno -> el objeto Alumno a guardar o actualizar.
     * @return -> el objeto Alumno guardado (con el ID autogenerado si es nuevo)
     * @throws SQLException ->Si ocurre un error al acceder a la base de datos
     */
    public Alumno guradarAlumno(Alumno alumno) throws SQLException{
        //ejemplo de logica de negocio en la capa de servicio: validacion antes de persistir
        if (alumno.getEdad() < 18) {
            throw new IllegalArgumentException("La edad del alumno debe ser mayor o igual a 18 años.");
        }
        //si el alumno tiene un ID, asumimos que es una actualizacion
        if (alumno.getId() != 0) {
            alumnoRepository.update(alumno);
            return alumno;
        } else {
            //si no tiene id, asumimos que es un nuevo registro
            alumnoRepository.create(alumno);
            return alumno;
        }
    }

    /**
     * Busca un alumno por su ID
     * @param id -> id del Alumno a buscar
     * @return -> objeto de la clase Alumno encontrado o null si  no existe
     * @throws SQLException
     */
    public Alumno buscarAlumnoPorId(int id) throws SQLException{
        return alumnoRepository.findById(id);
    }

    /**
     * Elimina un alumno por su ID
     * @param id -> id del alumno a eliminar.
     * @return -> 1 si lo pudo eliminar, 0 si no se pudo eliminar
     * @throws SQLException
     */
    public int eliminarAlumno(int id) throws SQLException{
        return alumnoRepository.delete(id);
    }

    /**
     * Busca alumnos por su ID de curso
     * @param idCurso -> el id del curso por el que hay que filtrar
     * @return -> lista de alumnos que pertenecen al curso buscado
     * @throws SQLException
     */
    public List<Alumno> buscarAlumnoPorCurso(int idCurso) throws SQLException{
        return alumnoRepository.findByCurso(idCurso);
    }
}
