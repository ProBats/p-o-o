package ar.org.centro8.java.curso.controllers;

import ar.org.centro8.java.curso.services.AlumnoService;
import ar.org.centro8.java.curso.services.CursoService;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class AlumnoController {
    //Inyectamos los servicios, no los repositorios directamente.
    //El controladores delega la logica de negocios a los servicios.
    private final AlumnoService alumnoService;
    private final CursoService cursoService;

    //el constructor completo genera la inyeccion de dependencias
    //Spring inyectara automaticamente las instacioas de AlumnoService y CursoService
}
