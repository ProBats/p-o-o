package ar.org.centro8.java.curso.excepciones;

public class Lector implements AutoCloseable{
    public Lector(){
        System.out.println("Se creo un lector.");
    }
    public void leer(){
        System.out.println("Se lee el media");// medio = recurso o fuente de datos
    }

    @Override
    public void close() throws Exception{
        System.out.println("Se cerro el medio.");
    }

}
