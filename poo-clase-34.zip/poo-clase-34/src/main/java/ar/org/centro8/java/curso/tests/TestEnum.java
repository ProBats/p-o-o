package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entities.enums.EjemploEnum;

public class TestEnum {
    public static void main(String[] args) {
        System.out.println(EjemploEnum.PENDIENTE);
        System.out.println(EjemploEnum.EN_PROCESO);
        System.out.println(EjemploEnum.ENTREGADO);
    }
}
