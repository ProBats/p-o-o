package ar.org.centro8.java.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.entities.Curso;
import ar.org.centro8.java.curso.entities.enums.Dia;
import ar.org.centro8.java.curso.entities.enums.Turno;
import ar.org.centro8.java.curso.repositories.interfaces.ICursoDAO;


@Repository
public class CursoRepository implements ICursoDAO{

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO cursos(titulo, profesor, dia , turno, activo) VALUES (?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM cursos WHERE id=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM cursos";
    private static final String SQL_UPDATE = "UPDATE cursos SET titulo=?, profesor=?, dia=?, turno=?, activo=? WHERE id=?";
    private static final String SQL_DELETE = "DELETE FROM cursos WHERE id=?";
    private static final String SQL_FIND_BY_DIA_TURNO = "SELECT * FROM cursos WHERE dia=? AND turno=?";

    public CursoRepository(DataSource dataSource){
        this.dataSource = dataSource;
    }

    @Override
    public void create(Curso curso) throws SQLException {
        try (Connection conn= dataSource.getConnection();
        PreparedStatement ps = conn.prepareStatement(SQL_CREATE,Statement.RETURN_GENERATED_KEYS)
        ) {
            ps.setString(1, curso.getTitulo());
            ps.setString(2, curso.getProfesor());
            ps.setString(3, curso.getDia().name());
            ps.setString(4, curso.getTurno().name());
            ps.setBoolean(5, curso.isActivo());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    curso.setId(1);
                }
            }
        } 
    }

    @Override
    public Curso findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            } 
        }
        return null;
    }

    @Override
    public List<Curso> findAll() throws SQLException {
        List<Curso> cursos = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps= conn.prepareStatement(SQL_FIND_ALL);
            ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                cursos.add(mapRow(rs));
            }
        } 
        return null;
    }

    @Override
    public int update(Curso curso) throws SQLException {
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, curso.getTitulo());
            ps.setString(2, curso.getProfesor());
            ps.setString(3, curso.getDia().name());
            ps.setString(4, curso.getTurno().name());
            ps.setInt(5, curso.getId());
            int filaAfectadas = ps.executeUpdate();
            return filaAfectadas;    
            }
        
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn= dataSource.getConnection();
            PreparedStatement ps= conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);

            int filaAfectada = ps.executeUpdate();
            return filaAfectada;
        } 
    }

    @Override
    public List<Curso> findByDiaAndTurno(Dia dia, Turno turno) throws SQLException {
        List<Curso> cursos= new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_DIA_TURNO)) {
            ps.setString(1, dia.name());
            ps.setString(2, turno.name());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cursos.add(mapRow(rs));
                }
            }
        }
        return cursos;
    }

    private Curso mapRow(ResultSet rs ) throws SQLException{
        Curso c = new Curso();
        c.setId(rs.getInt("id"));
        c.setTitulo(rs.getString("titulo"));
        c.setProfesor(rs.getString("profesor"));
        c.setDia(Dia.valueOf(rs.getString("dia").toUpperCase()));
        c.setTurno(Turno.valueOf(rs.getString("turno").toUpperCase()));
        c.setActivo(rs.getBoolean("activo"));
        return c;
    }
}