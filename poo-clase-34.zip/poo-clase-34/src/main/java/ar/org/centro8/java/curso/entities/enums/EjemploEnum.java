package ar.org.centro8.java.curso.entities.enums;

public enum EjemploEnum {
    //representamos estados de un pedido
    PENDIENTE("pendiente de envio"),
    EN_PROCESO("en proceso de preparacion"),
    ENTREGADO("entregado al cliente");

    private final String descripcion;

    private EjemploEnum(String descripcion){
        this.descripcion=descripcion;
    }

    @Override
    public String toString(){
        return name() + "->" + descripcion;
    }
    
}
