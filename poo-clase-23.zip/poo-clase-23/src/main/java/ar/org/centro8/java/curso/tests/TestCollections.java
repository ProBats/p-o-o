package ar.org.centro8.java.curso.tests;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

import ar.org.centro8.java.curso.entidades.arreglos.Auto;

public class TestCollections {
    public static void main(String[] args) {
        System.out.println("** Interface List **");

        /*
         * La interface List representa una lista con indices, que emula a un Array.
         * List es la unica que tiene metodos definidos como indices.
         * De esta interfaz se pueden elegir distintas implementaciones con distintas tecnologias.
         * ArrayList es una lista tipo vector que tiene por dentro un comportamiento similar a 
         * un Array, pero que no es un Array, ya que es completamente dinamico
         * LinkedList tiene todo el comportamiento heredado de List, pero internamente es una lista
         * enlazada.
         * La clase Vector tambien implementa List, no son los vectores que hemos visto anteriormente.
         * No se recomienda su uso, es una Tecnologia antigua. Tiene una sincronizacion excesiva, lo que
         * la hace demasiado lenta.
         * ArrayList es una lista tipo vector y LinkedList es una lista enlazada.
         * Hay una minima diferencia entre las dos y tiene que ver con la performance:
         * ArrayList es mas veloz para recorrer elementos
         * LinkedList es mas veloz para agregar y eliminar elementos
         */

         //Creo una referencia a la interfaz
        
        List lista;

        lista = new ArrayList<>();

        // .add() metodo para agregar elementos a un List
        lista.add(new Auto("Peugeot", "388", "Negro"));
        lista.add(new Auto("Chevrolet","Corsa","Rojo"));
        //Esta lista no tiene especificado un tipo de dato particular
        //en ese caso queda definida como una lista de la clase Object, por lo tanto, dentro
        //puedo guardar cualquier elemento.
        lista.add("Hola");
        lista.add(83);
        lista.add(23.45);
        
        //recorrido por indices
        System.out.println("Recorrido por indices");
        for (int i = 0; i < lista.size(); i++) { // el metodo size indica la longitud de la lista
            System.out.println(lista.get(i));
            //con el metodo .get() obtengo el valor de la posicion de indice que pase como parametro
        }

        //Eliminar un elemento
        lista.remove(3); //Elimina el elemento del indice 3

        System.out.println("--- recorrido con for-each ---");
        for (Object l : lista) {
                System.out.println(l);
        }
        
        /*
         * Interface Iterable
         * Iterable es el padre de todas las interfaces del framework Collections.
         * Dentro de Iterable se encuentra definido el metodo foreach(), es un metodo default.
         * Este metodo realiza un recorrido sobre la lista. No realizamos nosotros una estructura 
         * repetitiva, si no que es la misma lista que se autorecorre.
         * Aparecio a partir del JDK 8.
         * El metodo foreach() estara presente para todas la colecciones. 
         */

        System.out.println("\n -- Recorrido con metodo foreach()\n");

        lista.forEach(item -> System.out.println(item));
        //el foreach() recibe como parametro una Lambda Expression.
        //en este caso item representa a cada elemento de la lista, luego con el operador flecha
        //le indico que para ese parametro (el elemento de la lista) realiza la o las acciones que
        //siguen. En este caso, la accion es imprimir por consola el mismo elemento que se recibio
        // como parametro.
        System.out.println("");
        //Si quisieramos definir mas de una sentencia tenemos que abrir llaves
        lista.forEach(item ->{
            System.out.println(item);
            System.out.println("Otra accion...");
        });

        System.out.println();

        //Referencia de metodos (Method references)
        System.out.println("Recorrido con foreach() simplificado");
        lista.forEach(System.out::println);
        //Si solo vamos a escribir una unica sentencia, podemos omitir el uso del parametro y la flecha
        //con el operador :: le estamos indicando a Java que el item implicito lo coloque como
        //argumento del metodo.
        //Esta es una sintaxis moderna, comoda, prolija y abreviada.

        System.out.println("\n** ListIterator **");
        /*
         * Es una interfaz especializada para recorrer colleciones que implementan List.
         * A diferencia del iterator simple (Iterator) o del metodo foreach() de Iterable, ListIterator
         * ofrece funcionalidades adicionales:
         *  - recorrido bidireccional: permite avanzar y retroceder sobre las listas.
         *  -tiene acceso a indices
         *  -permite eliminar, reemplazar y agregar elementos durante la iteracion. 
         */

        List nombres = new ArrayList<>();
        nombres.add("Ricardo");
        nombres.add("Jenny");
        nombres.add("Carlos");
        nombres.add("Ana");
        nombres.add("Marcelo");

        //Vamos a obtener el ListIterator de la lista
        ListIterator<String> li = nombres.listIterator();
        
        //Recorrido hacia adelante
        System.out.println("\n -- recorrido hacia adelante --");
        while (li.hasNext()) { // hasNext(). comprueba si queda un elemento  mas por recorrer en adelante
            int indice = li.nextIndex(); //nextIndext() devuelve el indice del elemento que se devolvera
            String nombre = li.next(); //next() devuelve el siguiente metodo
            System.out.println("Indice "+indice + ": " + nombre);
        }

        //Recorrido hacia atras
        System.out.println("\n -- Recorrido hacia atras -- ");
        
        while (li.hasPrevious()) {
            int indice = li.previousIndex();
            String nombre = li.previous();
            System.out.println("Indice "+indice + ": " + nombre);
            
        }
        
        //Reemplazar elementos
        while (li.hasNext()) { 
            String nombre = li.next(); 
            if (nombre.toLowerCase().equals("carlos")) li.set("david"); // reemplazar el nombre de carlos, por David
        }
        System.out.println("\nLista despues de reemplazar a Carlos por David:" + nombres);


        //reinicio la posicion del puntero del ListIterator

        li = nombres.listIterator();

        //agregar elementos
        while (li.hasNext()) {
            String nombre = li.next();
            if (nombre.equals("Ana")) li.add("Juan"); //Agrega a Juan despues de Ana
        }
        System.out.println("\n Lista despues de agregar a Juan luego de Ana: " + nombres);

        //Eliminar elementos

        while (li.hasPrevious()) {
            String nombre = li.previous();
            if (nombre.equals("Jenny")) li.remove(); // Elimina el elemento actual
        }
        System.out.println("\n Lista despues de eliminar el elemento 'Jenny': " + nombres);

        //Generics
        /*
         * Para especificar el tipo de dato de una coleeccion lo hacemos a traves de una generics.
         * Los generics aparecieron a partir del JDK 5 y son una caracteristica que permite crear
         * clases, interfaces o metodos con tipos de datos parametrizados
         * Esto significa que podemos definir estructuras de datos y metodos que funcionen con 
         * cualquier tipo de dato, pero manteniendo la seguridad de tipos en tiempo de compilacion.
         * Los Generics permiten que una clase  o metodo trabaje con diferentes tipos de datos sin
         * tener que escribir varias versiones del mismo codigo.
         */

        List<Auto> listaAuto = new ArrayList<>();
        //No se pueden crear colecciones de tipos de datos primitivos, es decir, no se pueden 
        // poner  tipos de datos primitivos  en  los Generics, para eso se utilizan los wrappers
        // int -> Integer, double -> Double, float -> Float, char -> Character, boolean -> Boolean

        listaAuto.add(new Auto("Renault", "Clio", "Verde Fuego"));
        // lista.Auto.add("Hola"); ERROR, no puedo agreagr otro tipo de dato a la lista.

        //si quiero asignar a una variable del tipo Auto un elemento de la lista de Object, que 
        //sea un Auto, la voy a tener de castear primero.

        Auto auto1 = (Auto) listaAuto.get(0);

        //Si asignamos un elemento de listaAuto no hace falta castear, porque la lista ya es del tipo Auto

        Auto auto2 = listaAuto.get(0);

        //copiar los autos de lista a listaAuto
        //para copiar, tenemos que tener en cuenta que no todos los elementos de la lista son autos.
        lista.forEach(item -> {
            if (item instanceof Auto) {
                listaAuto.add((Auto) item); 
            }
        });

        System.out.println("\n Recorrido de la listaAuto");
        listaAuto.forEach(System.out::println);

        ///////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("\n $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ \n");

        System.out.println("\n ** Interface Set ** ");
        /*
         * La interface Set implementa Collection y tiene 3 implementaciones.
         * La interfaz Set provee una lista sin indices. El mismo objeto contenido en la lista
         * es el indice. Por esa misma razon, no se admiten valores duplicados.
         */

         //HashSet
        // La implementacion HashSet es la mas veloz de todas las implementaciones de Set-
        Set<String> setSemana;
        setSemana = new HashSet<>();
        setSemana = new LinkedHashSet<>();
        setSemana = new TreeSet<>();

        //Agregamos elementos al set
        setSemana.add("Lunes");
        setSemana.add("Martes");
        setSemana.add("Miercoles");
        setSemana.add("Jueves");
        setSemana.add("Viernes");
        setSemana.add("Sabado");
        setSemana.add("Domingo");
        
        //no podemos hacer un recorrido por indices, justamente porque no tiene  indices.
        //Podemos saber la longitud, pero no tiene indices
        System.out.println("\n Recorrido del set");
        setSemana.forEach(System.out::println);
        //HashSet no brinda un ordenamiento especifico. Lo recorre de la manera mas rapida posible.

        //LinkedHashSet
        /*
         * Es otra implementacion de Set. Por lo tanto, no permite valores duplicados y no hay indices
         * No es rapida como HashSet, auntque ese comportamiento no se va a notar en proyectos chicos
         * Almacena los elementos en una lista enlazada, esto quiere decir que cuando recorremos la lista
         * vamos a ver los elementos por orden de entrada
         */

         //TreeSet
        /*
         * La clase TreeSet implementa SortedSet, que extiende de Set.
         * Al usar TreeSet, la clase del Generic debe implementar la interfaz Comparable.
         * Es una implementacion que almacena en un arbol de orden natural
         * Esto quiere decir que los elementos van a aparecer ordenados. En este caso, al ser
         * elementos del tipo String, el ordenamiento va a ser alfabetico.
         * No necesitamos un codigo de ordenamiento especifico
         */

         //Creamos un Set de Auto
        Set<Auto> setAutos;
        //setAutos = new HashSet<>();
        //setAutos = new LinkedHashSet<>();
        setAutos = new TreeSet<>();

        //agregamos los autos de listaAuto a setAutos
        //lo recorremos con foreach y agregamos con expresion lambda
        listaAuto.forEach(setAutos::add);
        listaAuto.forEach(auto -> setAutos.add(auto));
        //Esta seria la forma mas larga de la misma sentencia.
        //tambien podemos utilizar el metodo definido en la interfaz Collections, addAll()
        setAutos.addAll(listaAuto);


        System.out.println("\n -- recorrido de setAutos --");
        setAutos.forEach(System.out::println);
    }
}
