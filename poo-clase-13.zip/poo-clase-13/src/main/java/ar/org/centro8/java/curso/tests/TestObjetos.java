package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.ClientePersona;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Empleado;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Persona;

public class TestObjetos {
    public static void main(String[] args) {
    /*
     * En java la clase Class, y Java, internamente, toma a todas las clases que nosotros
     * creamos como objetos de la clase Class, en tiempo de ejecucion.
     * Los atributos son tratados en Java como objetos de la clase Field, que se encuentra en el 
     * paquete java.lang.reflect.Field
     * Los metodos son tratados internamente como objetos de la clase method que se encuentra en el paquete
     * java.lang.reflect.Method
     * Esta es la base del API de reflexion de Java, la cual nos permite inspeccionar y manipular
     * informacion de clases, metodos y atributos en tiempo de ejecucion.
     * Aunque nosotros no creemos los objetos de Field o Method directamente, el compilador y la
     * JVM generan estos objetos internamente para gestionar la informacion de nuestras clases.
     * Las clases publicos de java.lang son accesibles de manera global. 
     */

    Direccion direccion1 = new Direccion("Av. Medrano", 162, "2", "8");
    Cuenta cuenta1 = new Cuenta(1, "Pesos argentinos");
    Persona persona1 = new Empleado("Saul", "Hudson", 51, direccion1, 65, 1_500_000);
    //el guion bajo es estetico, no modifica el comportamiento, solo sirve para
    //separar visualmente las unidades
    System.out.println(persona1);

    Persona persona2 = new ClientePersona("Franco", "Colapinto", 22, direccion1, 10, cuenta1);
    
    //Si queremos guardar persona1 dentro de un objeto de EMpleado, tenemos un error
    //ya que persona1 esta guardada dentro de un contenedor mayor, que es el del tipo Persona
    //Empleado enpleado1 = persona1;
    //castear significa convertir una variable de un tipo a otro
    //es una fomrma de indicarle al compilador que se trate a un objeto o valor como si fuera de otro tipo
    Empleado empleado1 = (Empleado)persona1;
    //si pasaramos otro tipo de dato, Java lo va a intentar asignar igual, pero va a arrojar una 
    //java.lang.ClassCastException y 
    }
    
}
