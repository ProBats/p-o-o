package ar.org.centro8.java.curso.tests;

import java.util.Scanner;

import ar.org.centro8.java.curso.interfaces.I_Archivo;

public class TestInterfaces {
    public static void main(String[] args) {
        //creamos una referencia de interfaz 
        I_Archivo archivo;

        //inicializacion:
        Scanner teclado = new Scanner(System.in);

        System.out.println("ingrese una Oracion: ");
        String mensaje= teclado.nextLine();
        System.out.println("Seleccione en que tipo de archivo quiere guardar su texto: ");
        System.out.println("BINARIO -TEXTO - NUBE");
        String opcion = teclado.nextLine();
        teclado.close();
        //en programas pequeños o en contexto de enseñanza, cerrar el Scanner no es critico,
        // pero en aplicaciones reales es buena practica liberar recursos

        archivo = I_Archivo.crearArchivo(opcion);
        
        archivo.setText(mensaje);
        archivo.info();
        System.out.println(archivo.getText());
    }
}
