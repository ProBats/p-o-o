package ar.org.centro8.java.curso.interfaces.implementaciones;

import ar.org.centro8.java.curso.interfaces.I_Archivo;

public class ArchivoTexto implements I_Archivo {
    //La clase esta obligada a sobreescribir los metodos abstractos
    //la clase puede heredar de otra clase(extends + el nombre de la clase padre)
    //La clase puede implementar varias interfaces (se separan los nombres de cada una con coma).
    //Si una clase implementa multiples interfaces que contiene un metodo default con la misma firma,
    // la clase debe sobreescribir dicho metodo para resolver la ambiguedad.
    private String texto;

    @Override
    public void setText(String texto) {
        System.out.printf("Guardando '%s' dentro de archivo de texto\n", texto);
        this.texto = texto;
    }

    @Override
    public String getText() {
        return this.texto;
    }

    @Override
    public String getTipo() {
        return "Archivo texto";
    }
}
