package ar.org.centro8.java.curso.ejercicios.figuras;

public abstract class FiguraGeometrica {

    public abstract double getPerimetro();
    public abstract double getSuperficie();
}
