package ar.org.centro8.java.curso.ejercicios.interfaces;

public interface IPagos {
    //Se establece el contrato que puede servir para cualquier clase que lo implemente
    //cada clase debera definir el comportamiento y la tecnologia que se necesite para implementar cada metodo
    
    void pagarConTarjetaDebito(double monto);
    void pagarConTarjetaCredito(double monto);
    void pagarConTransferencia(double monto);
    void pagarConEfectivo(double monto);
    void pagarConQR(double monto);

    /**
     * Metodo que retorna el monto ingresado redondeado a 2 decimales
     * @param monto -> monto inicial
     * @return -> retorna el monto redondeado a 2 decimales
     */
    default double montoFormateado(double monto){
        return Math.round(monto * 100.0)/100.0;
        //123.45678
        // * 100.0 -> 12345.6789
        // round redondea al valor mas cercado =12346
        // /100 mueve la coma 2 decimales 123.46
    }

    /**
     * Metodo que retorna el resultado de aplicar un descuento de porcentaje que se ingresa como parametro.
     * @param monto -> monto inicial
     * @param descuento -> porcentaje del recargo
     * @return -> monto final con el recargo aplicado
     */
    default double aplicarDescuentos(double monto, double descuento){
        return monto - (monto / 100.0 * descuento);
    }

    /**
     * Metodo que retorna el resultado de aplicar un recargo de porcentaje que se ingresa como parametro.
     * @param monto -> monto inicial
     * @param recargo -> porcentaje del recargo
     * @return -> monto final con el recargo aplicado
     */
    default double aplicarRecargo(double monto, double recargo){
        return monto + (monto / 100.0 * recargo);
    }
}
