    package ar.org.centro8.java.curso.interfaces;

    import ar.org.centro8.java.curso.interfaces.implementaciones.ArchivoBinario;
    import ar.org.centro8.java.curso.interfaces.implementaciones.ArchivoNube;
    import ar.org.centro8.java.curso.interfaces.implementaciones.ArchivoTexto;

    public interface I_Archivo {
        /*
        * No tienen constructores, ya que no se pueden crear objetos de una interfaz
        * Todas las variables declaradas (atributos) en una interfaz son implicitamente
        * public static final
        * Pueden tener metodos abstractos
        * Por defecto, los metodos de una interfaz son publicos, pero a partir del JDK 9, se pueden definir metodos privados para uso interno
        * Los metodos de una interfaz son por defecto abstractos y por lo tanto, no tienen cuerpo.
        * Las clases que imlementen la interfaz deben ponerle el cuerpo al metodo
        * A partir del JDK 8 se pueden definir metodos default y estaticos. Estos metodos incluyen
        * implementacion. Ese codigo sera compartido por todas las clases que implementen la interfaz.
        * Se pueden sobreescribir los metodos si requieren una implementacion especifica
        * Una clase puede implementar todas las interfaces que desee
        * Como una clase puede implementar varias interfaces, se da una situacion similar a lo que seria
        * una herencia multiple, que no existe en Java
        * No llega a ser una herencia multiple porque no hereda constructores.
        */

        //No hace falta escribir las palabras static y abstract, se pueden evitar su uso normalmente
        //o se puede declarar para un mayor claridad en el codigo, como se desea

        /**
         * Metodo para escribir en el archivo
         * @param texto ->texto a escribir
         */
        void setText(String texto);

        /**
         * Metodo para leer un archivo
         * @return -> retorna el texto del archivo
         */
        String getText();

        /**
         * Metodo que retorna en forma de cadena el tipo del archivo
         * @return
         */
        String getTipo();

        default void info(){
            System.out.println("I_Archivo: Interfaz para la gestion de archivos. Define el comportamiento comun para todas las implementaciones");
        }

        //Factory Methods (Metodos de fabrica)
        //Permiten centralizar la creacion de instancias de las clases que implementan la interfaaz.
        //Esto sirve para ocultar la logica de instanciacion y decidir, en funcion de los parametros
        //que implementacion devolver
        public static I_Archivo crearArchivo(String tipo){
            switch (tipo.toLowerCase()) {
                case "texto": return new ArchivoTexto();
                case "binario" : return new ArchivoBinario();
                case "nube": return new ArchivoNube();
                default: throw new IllegalArgumentException("Tipo de archivo no soportado: " + tipo);
            }
        }
        //esto es un polimorfismo por interfaz
        //aunque el metodo retorne un objeto del tipo I_Archivo, la instancia concreta puede ser de 
        //cualquiera de las clases que implementen la interfaz. Por lo tanto, el objeto retirnado
        //puede comportarse de distintas maneras segun la implementacion concreta que se devuelva.
    }
