package ar.org.centro8.java.curso.tests;

import java.util.Scanner;

public class TestString {
    public static void main(String[] args) {
        System.out.println("** Clase String **");

        //podemos crear un objeto de la clase String de carias maneras
        String texto1 = "Cadena de texto!";
        String texto2 = new String("Hola");
        String texto3 ="hola";

        //metodos para comparar
        //al comparar con el comparador == va a comparar que sean el mismo objeto en memoria
        System.out.println(texto2 == "Hola");
        //hay una oportunidad en la que la comparacion podria darnos un true
        System.out.println(texto3 == "hola");
        //existe un comportamiento especial denominado "intering"
        //lo que sucede es que las cadenas creadas con comillas dobles se almacenan en un pool
        // de cadenas internas para ahorrar memoria, es decir, que de manera interna, ocuparian 
        //el mismo espacio en memoria. Por eso se las considera iguales.
        //Comparar contenidos de cadenas con el == no brinda un comportamiento garantizado.
        //Por lo tanto para comparar cadenas de caracteres teniendo en cuenta su contenido, se utilizan
        //los metodos .equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola"));
        System.out.println(texto2.equalsIgnoreCase("hola"));
        //IgnoreCase ignora las mayusculas y las minisculas

        //pasar una cadena a minuscula o mayuscula
        //.toLowerCase() .toUpperCase()

        System.out.println(texto1.toLowerCase());
        System.out.println(texto1.toUpperCase());

        //.contains()
        //devuelve un booleano indicando si contiene la subcadena ingresada como parametro
        System.out.println(texto1.contains("hola")); // false
        System.out.println(texto3.contains("hola")); // true

        //.length()
        //devuelve la longitud del vector, es decir, cuantos caracteres tiene la cadena
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4

        //.isEmpty()
        //indica si la cadena esta vacia, es decir si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); // false

        //.isBlank() aparece a partir del JDK11
        //indica si una cadena esta en blanco o si consiste unicamente en espacios en blanco
        //como por ejemplo si solo contiene espacios, tabulaciones y/o saltos de linea
        String texto4 = " ";
        System.out.println(texto4.isEmpty()); 
        System.out.println(texto4.isBlank()); 

        //charAt()
        //devuelve el caracter el indice indicado como parametro
        System.out.println(texto1.charAt(3));
        System.out.println(texto2.charAt(3));

        //.indexOf()
        //decuelve el indice de la primera ocurrencia de a subcadena
        // si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto"));
        System.out.println(texto1.indexOf("Texto"));

        //startsWith() .endsWith()
        //devuelve  un booleano que indica si la candena comienza o termina con un texto deternimado
        System.out.println(texto1.startsWith("hola"));
        System.out.println(texto2.startsWith("Hola"));
        System.out.println(texto1.endsWith("exto"));
        System.out.println(texto2.endsWith("exto!"));


        //substring()
        //extrae una subcadena desde la posicion que le indiquemos como parametro
        System.out.println(texto1.substring(10)); //Texto!
        //con dos parametros indicamos la posicion de inicio y la posicion de final de la subcadena
        //la posicion final, no se incluye en la devolucion
        System.out.println(texto1.substring(0, 6)); //Cadena

        //metodo replace
        //reemplazar un caracter por otro
        System.out.println(texto1.replace('e', 'i')); // Cadina di Tixto!
        //reemplaza una cadena de caracteres por otra
        System.out.println(texto1.replace("Texto", "caracteres"));
        System.out.println(texto1);
        texto3 = "manzana, manzana, naranja";
        //reemplazar solo la primera vez que aparezca la cadena
        System.out.println(texto3.replaceFirst("manzana", "banana"));
        // reemplazar todas las veces que aparezca la cadena
        System.out.println(texto3.replaceAll("manzana", "banana"));

        //si bien replace() y replaceAll() reemplazan todas las apariciones 
        //replaceAll() es mucho mas potente, permite buscar y reemplazar patrones de expresiones regulares
        //Se conocen como regex o regexp. Una expresion regular es una secuencia de caracteres que definen un patron 
        //en este caso es un patron de busqueda. Los patrones indican que reglas deben seguir las distintas instrucciones
        String texto5 = "Mi numero de telefono es 011-8888-9999 y mi numero laboral es 011-555-4444";
        System.out.println(texto5.replaceAll("\\d{3}-\\d{4}-\\d{4}", "HIDDEN INFORMATION"));

        //repeat()
        //repite la cadena la cantidad de veces  que se indique como parametro
        System.out.println(texto2.repeat(3));

        //caracteres de escape
        //son secuencias especiales de caracteres que se utilizan en cadenas de texto y literales
        //de caracteres para representar caracteres especiales que no se pueden representar directamente
        //Los caracteres de escape comienzan con una barra invertida(\) seguida de un caracter que 
        //indica que tipo de escape se esta utilizando
        //algunos ejemplos:

        //\n salto de linea
        System.out.println("Hola\nMundo!");

        // \t tabulaciones
        System.out.println("Hola\tMundo!");

        // \* comillas dobles
        System.out.println("\"Hola Mundo!\"");

        // \\ barra invertida
        System.out.println("\\Hola Mundo!\\");

        // pedirle al usuario que ingrese su nombre completo (solo primer nombre y solo el primer apellido)
        // mostrar luego, primero el apellido y luego el nombre, con la primera letra en mayuscula
        //el resto en minuscula

        String nombreApellido = "Eldie Gote";
        String nombre="";
        String apellido="";
        for (int i = 0; i < nombreApellido.length(); i++) {
            char letra = nombreApellido.charAt(i);
            
            if (letra == ' ') {
                apellido = nombreApellido.substring(i + 1, nombreApellido.length());
                i = nombreApellido.length();
            }else{
                nombre += nombreApellido.charAt(i);
                
            }
        }
        System.out.println(apellido+ " " + nombre);

    }
}
