package ar.org.centro8.java.curso.ejercicios.interfaces.implementaciones;

import ar.org.centro8.java.curso.ejercicios.interfaces.IPagos;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Subscripcion implements IPagos{
    private String plan;
    private double costoMensual;

        @Override
    public void pagarConTarjetaDebito(double monto) {
        // aca va toda la logica de pago con tarjeta de debito
        System.out.println("Se realizo el pago con tarjeta de debito");
    }

    @Override
    public void pagarConTarjetaCredito(double monto) {
        // aca va toda la logica de pago con tarjeta de credito
        System.out.println("Se aplica un recargo del 10%");
        System.out.println("Total cobrado = "+ montoFormateado(aplicarRecargo(monto, 10)));
    }

    @Override
    public void pagarConTransferencia(double monto) {
        // aca la logica de pago con Transferencia
    }

    @Override
    public void pagarConEfectivo(double monto) {
        // se anula el comportamiento del metodo
        System.out.println("Metodo de pago no valido para una subscripcion");
    }
    
    @Override
    public void pagarConQR(double monto) {
        // se anula el comportamiento del metodo
        System.out.println("Metodo de pago no valido para una subscripcion");
    }

    @Override
    public double aplicarDescuentos(double monto, double descuento) {
        // TODO Auto-generated method stub
        return IPagos.super.aplicarDescuentos(monto, descuento);
    }

    
}
