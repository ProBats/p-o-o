package ar.org.centro8.java.curso.ejercicios.interfaces.implementaciones;

import ar.org.centro8.java.curso.ejercicios.interfaces.IPagos;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Servicio implements IPagos{
    private String descripcion;
    private String tarifa;

        @Override
    public void pagarConTarjetaDebito(double monto) {
        // aca va toda la logica de pago con tarjeta de debito
        System.out.println("Se realizo el pago con tarjeta de debito");
    }

    @Override
    public void pagarConTarjetaCredito(double monto) {
        // aca va toda la logica de pago con tarjeta de credito
        System.out.println("Se aplica un recargo del 10%");
        System.out.println("Total cobrado = "+ montoFormateado(aplicarRecargo(monto, 10)));
    }

    @Override
    public void pagarConTransferencia(double monto) {
        // aca la logica de pago con Transferencia
    }

    @Override
    public void pagarConEfectivo(double monto) {
        // aca va la logica de pago con efectivo
        System.out.println("Se aplica un descuento del 10%");
        System.out.println("Total cobrado = " + montoFormateado(aplicarDescuentos(monto, 10)));
    }
    
    @Override
    public void pagarConQR(double monto) {
        // aca va la logica de pago con QR
    }
}
