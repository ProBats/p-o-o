package ar.org.centro8.java.curso.tests;

public class TestString {
    public static void main(String[] args) {
        System.out.println("** Clase String **");

        //podemos crear un objeto de la clase String de carias maneras
        String texto1 = "Cadena de texto!";
        String texto2 = new String("Hola");
        String texto3 ="hola";

        //metodos para comparar
        //al comparar con el comparador == va a comparar que sean el mismo objeto en memoria
        System.out.println(texto2 == "Hola");
        //hay una oportunidad en la que la comparacion podria darnos un true
        System.out.println(texto3 == "hola");
        //existe un comportamiento especial denominado "intering"
        //lo que sucede es que las cadenas creadas con comillas dobles se almacenan en un pool
        // de cadenas internas para ahorrar memoria, es decir, que de manera interna, ocuparian 
        //el mismo espacio en memoria. Por eso se las considera iguales.
        //Comparar contenidos de cadenas con el == no brinda un comportamiento garantizado.
        //Por lo tanto para comparar cadenas de caracteres teniendo en cuenta su contenido, se utilizan
        //los metodos .equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola"));
        System.out.println(texto2.equalsIgnoreCase("hola"));
        //IgnoreCase ignora las mayusculas y las minisculas

        //pasar una cadena a minuscula o mayuscula
        //.toLowerCase() .toUpperCase()

        System.out.println(texto1.toLowerCase());
        System.out.println(texto1.toUpperCase());

        //.contains()
        //devuelve un booleano indicando si contiene la subcadena ingresada como parametro
        System.out.println(texto1.contains("hola")); // false
        System.out.println(texto3.contains("hola")); // true

        //.length()
        //devuelve la longitud del vector, es decir, cuantos caracteres tiene la cadena
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4

        //.isEmpty()
        //indica si la cadena esta vacia, es decir si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); // false

        //.isBlank() aparece a partir del JDK11
        //indica si una cadena esta en blanco o si consiste unicamente en espacios en blanco
        //como por ejemplo si solo contiene espacios, tabulaciones y/o saltos de linea
        String texto4 = " ";
        System.out.println(texto4.isEmpty()); 
        System.out.println(texto4.isBlank()); 

        //charAt()
        //devuelve el caracter el indice indicado como parametro
        System.out.println(texto1.charAt(3));
        System.out.println(texto2.charAt(3));

    }
}
