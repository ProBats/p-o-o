package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.objetos.Dato;
import ar.org.centro8.java.curso.entidades.relaciones.Cuenta;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.ClientePersona;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Direccion;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Empleado;
import ar.org.centro8.java.curso.entidades.relaciones.herencia.Persona;

public class TestObjetos {
    public static void main(String[] args) {
    /*
     * En java la clase Class, y Java, internamente, toma a todas las clases que nosotros
     * creamos como objetos de la clase Class, en tiempo de ejecucion.
     * Los atributos son tratados en Java como objetos de la clase Field, que se encuentra en el 
     * paquete java.lang.reflect.Field
     * Los metodos son tratados internamente como objetos de la clase method que se encuentra en el paquete
     * java.lang.reflect.Method
     * Esta es la base del API de reflexion de Java, la cual nos permite inspeccionar y manipular
     * informacion de clases, metodos y atributos en tiempo de ejecucion.
     * Aunque nosotros no creemos los objetos de Field o Method directamente, el compilador y la
     * JVM generan estos objetos internamente para gestionar la informacion de nuestras clases.
     * Las clases publicos de java.lang son accesibles de manera global. 
     */

    Direccion direccion1 = new Direccion("Av. Medrano", 162, "2", "8");
    Cuenta cuenta1 = new Cuenta(1, "Pesos argentinos");
    Persona persona1 = new Empleado("Saul", "Hudson", 51, direccion1, 65, 1_500_000);
    //el guion bajo es estetico, no modifica el comportamiento, solo sirve para
    //separar visualmente las unidades
    System.out.println(persona1);

    Persona persona2 = new ClientePersona("Franco", "Colapinto", 22, direccion1, 10, cuenta1);
    
    //Si queremos guardar persona1 dentro de un objeto de EMpleado, tenemos un error
    //ya que persona1 esta guardada dentro de un contenedor mayor, que es el del tipo Persona
    //Empleado enpleado1 = persona1;
    //castear significa convertir una variable de un tipo a otro
    //es una fomrma de indicarle al compilador que se trate a un objeto o valor como si fuera de otro tipo
    //Empleado empleado1 = (Empleado)persona1;
    //si pasaramos otro tipo de dato, Java lo va a intentar asignar igual, pero va a arrojar una 
    //java.lang.ClassCastException y detendra el programa.
    //para salvar esta situacion podriamos utilizar el intanceOf hunto con el operador ternario
    Empleado empleado1 = (persona1 instanceof Empleado)? (Empleado) persona1 : null;
    System.out.println(empleado1);
    
    //Los objetos tienen acceso a los mienbros de su clase mas todo lo heredado de la clase padre
    // y de la clase Object (clase padre de todas las clases)
    //El objeto de una clase padre, no puede tener acceso a los miembros de sus clases hijas.

    System.out.println();

    Dato d1 = new Dato(2);
    Dato d2 = d1; // Es un apuntador al mismo espacio de memoria
    Dato d3 = new Dato(2); // Es un nuevo objeto, es un nuevo espacio de memoria
    Dato d4 = new Dato(4);
    String st = "2";

    //El metodo hashCode() es un metodo heredado de la clase Object
    //El codigo hash es un valor entero calculado por Java a partir del estado o la identidad
    //del objeto. Este valor se utiliza principalmente en estructuras de datos hash para 
    // facilitar la busqueda y el almacenamiento eficiente de objetos. No es la direccion de memoria del objeto.

    System.out.println("d1.hashCode(): " + d1.hashCode());
    System.out.println("d2.hashCode(): " + d2.hashCode());
    System.out.println("d3.hashCode(): " + d3.hashCode());
    System.out.println("d4.hashCode(): " + d4.hashCode());
    System.out.println("st.hashCode(): " + st.hashCode());
    //vemos que d1 y d2 tienen el mismo hashCode() porque son considerados el mismo objeto

    //el metodo equals() tambien esta definidos en a clase Object
    //compara objetos por medio del hasCode, devuelve un booleano
    System.out.println("d1.equals(d1): " + d1.equals(d1) ); //true
    System.out.println("d1.equals(d2): " + d1.equals(d2) ); //true
    System.out.println("d1.equals(d3): " + d1.equals(d3) ); //false
    System.out.println("d1.equals(d4): " + d1.equals(d4) ); //false
    System.out.println("d1.equals(st): " + d1.equals(st) ); //false

    //puede darse la situacion de que debamos considerar que dos objetos con el mismo estado
    // sean tomados como el mismo objeto
    //Esto pasa con la clase String por ejemplo
    //si comparamos dos objetos del tipo String  con el metodo .equals() por mas que sean dos
    //objetos con distinto lugar de memoria, van a ser considerados el mismo objeto si tienen el mismo estado porque
    //en la clase String los metodos .equals() y hashCode() estan sobreescritos.

    //vamos a sobreescribir esos metodos en la clase Dato para que los objetos con el mismo
    // estado sean considerados el mismo Objeto
    
    }
    
}
