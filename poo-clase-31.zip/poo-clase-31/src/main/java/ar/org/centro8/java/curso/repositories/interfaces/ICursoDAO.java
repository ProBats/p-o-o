package ar.org.centro8.java.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.entities.Curso;
import ar.org.centro8.java.curso.entities.enums.Dia;
import ar.org.centro8.java.curso.entities.enums.Turno;

public interface ICursoDAO {
    void create(Curso curso) throws SQLException;

    /**
     * Metodo que busca un Alumno por su id. Se pasa como parametro un id
     * @param id
     * @return
     * @throws SQLException
     */
    Curso findById(int id) throws SQLException;
    List<Curso> findAll() throws SQLException;
    int update (Curso curso) throws SQLException;

    /**
     * Metodo para eliminar un registro de ALumno. Recibe un id alumno como parametro y elimina
     * el registro en la base
     * @param id
     * @return
     * @throws SQLException
     */
    int delete(int id) throws SQLException;
    
    List<Curso> finByDiaAndTurno(Dia dia, Turno turno) throws SQLException;
}
