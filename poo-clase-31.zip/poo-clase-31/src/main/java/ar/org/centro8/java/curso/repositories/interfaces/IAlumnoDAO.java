package ar.org.centro8.java.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.entities.Alumno;

public interface IAlumnoDAO {
    //Estos metodos podrian lanzar una SQLException que es una checked exception, por lo tanto,
    //el compilador nos obliga a que capturemos o declaremos la exception

    /*
     * Metodo para crear un nuevo alumno en la base. Recibe un objeto de la clase Alumno.
     * Y lo guarda como un registro en la base
     */
    void create(Alumno alumno) throws SQLException;

    /**
     * Metodo que busca un Alumno por su id. Se pasa como parametro un id
     * @param id
     * @return
     * @throws SQLException
     */
    Alumno findById(int id) throws SQLException;
    List<Alumno> findAll() throws SQLException;
    int update (Alumno alumno) throws SQLException;

    /**
     * Metodo para eliminar un registro de ALumno. Recibe un id alumno como parametro y elimina
     * el registro en la base
     * @param id
     * @return
     * @throws SQLException
     */
    int delete(int id) throws SQLException;
    /**
     * Metodo que retorna una lista de alumnos que sean 
     * @param idCUrso
     * @return
     * @throws SQLException
     */
    List<Alumno> findByCurso(int idCUrso) throws SQLException;
}

// CRUD
// Create Read Update Delete
// Representa las 4 operaciones basicas de crear, leer, actualizar y borrar.