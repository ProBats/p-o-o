package ar.org.centro8.java.curso.tests;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/*
 * Esta clase de prueba para validar la configuracion de HikariCP con Datasource
 * y establecer la conexion a la BD.
 */
public class TestConnection {
    public static void main(String[] args) {
        
        Properties props = new Properties();
        //Creadmos un objeto de Properties para cargar el fichero de configuracion

        try (InputStream in = TestConnection.class //Obtenemos el objeto Class de esta clase
                                .getClassLoader() //obtenemos el getClassLoader() que es el responsable de cargar clases y recursos en tiempo de ejecucion
                                .getResourceAsStream("application.properties")) { //Busca el archivo que le pasamos como parametro y lo devuelve como un flujo de bytes
            if (in ==null) {
                System.err.println("No se encontro el application.properties en el classpath");
                return;
            }
            props.load(in);
        } catch (Exception e) {
            System.err.println("Error cargando propiedades: " + e.getMessage());
            return;
        }

        //Creamos la configuracion del pool
        HikariConfig config = new HikariConfig();

        //leemos la URL de la DB 
        config.setJdbcUrl(props.getProperty("spring.datasource.url"));
        //obtenemos usuario y contraseña para conectarnos
        config.setUsername(props.getProperty("spring.datasource.username"));
        config.setPassword(props.getProperty("spring.datasource.password"));

        //Creamos el datasource con el pool de de conexiones y probamos la conexion

        try (HikariDataSource ds = new HikariDataSource(config);
            Connection conn = ds.getConnection()) { //obtenemos la conexion
            if (conn.isValid(2)){ // esto comprueba si la coexion es valida. El parametro indica la cantidad de segundos que el driver JDBC va a esperar para confirmar la conexion con el servidor.
                System.out.println("Conexion exitosa a: "
                                    + conn.getMetaData().getURL());// con el getMetaData() obenemos la informacion sobre la conexion activa
                                                                //getUrl retorna la URL de la conexion utilizada
                                                                //la imprimimos para verificar a que base de datos nos conectamos.
            } else {
                System.err.println("Conecion establecida pero no valida");
            }
        } catch (Exception e) {
            System.err.println("No se pudo conectar" + e.getMessage());
        }

    }
}
