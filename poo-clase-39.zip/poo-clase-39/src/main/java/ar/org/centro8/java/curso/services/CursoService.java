package ar.org.centro8.java.curso.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import ar.org.centro8.java.curso.models.entities.Curso;
import ar.org.centro8.java.curso.models.entities.enums.Dia;
import ar.org.centro8.java.curso.models.entities.enums.Turno;
import ar.org.centro8.java.curso.models.repositories.interfaces.ICursoRepository;
import lombok.AllArgsConstructor;
/**
 * Clase de servicio para la entidad Curso.
 * Encapsula la logica de negocio relacionada con los cursos
 */
@Service
@AllArgsConstructor
public class CursoService {
    private final ICursoRepository cursoRepository;

    /**
     * obtiene una lista de todos los cursos.
     * Aqui se vuelve la logica de negocio adicional antes o despues de la llamada al repositorio.
     * @return -> lista de objetos de la clase Curso
     * @throws SQLException -> puede lanzar una excepcion al acceder a la BD
     */
    public List<Curso> obtenerTodosLosCursos() throws SQLException{
        return cursoRepository.findAll();
    }

    /**
     * Guarda un nuevo curso o actualiza uno existente.
     * Este metodo encapsulado la logica de persistir un curso.
     * @param curso -> el objeto Curso a guardar o actualizar.
     * @return -> el objeto Curso guardado (con el ID autogenerado si es nuevo)
     * @throws SQLException -> Si ocurre un error al acceder a la base de datos
     */
    public Curso guardarCurso(Curso curso) throws SQLException{
        //ejemplo de logica de negocio: asegurar que un nuevo curso sea activo por defecto
        if(curso.getId() == 0) curso.setActivo(true);
        //se podrian agregar mas validaciones como que el titulo no esta duplicado, por ejemplo

        if (curso.getId() != 0) {
            cursoRepository.update(curso);
            return curso;
        } else {
            cursoRepository.create(curso);
            return curso;
        }
    }

    /**
     * Busca un Curso por su ID
     * @param id -> id del Curso a buscar
     * @return -> objeto de la clase Curso encontrado o null si  no existe
     * @throws SQLException
     */
    public Curso buscarCursoPorId(int idCurso) throws SQLException{
        return cursoRepository.findById(idCurso);
    }

    /**
     * Elimina un curso por su ID
     * @param id -> id del curso a eliminar.
     * @return -> 1 si lo pudo eliminar, 0 si no se pudo eliminar
     * @throws SQLException
     */
    public int eliminarCurso(int idCurso) throws SQLException{
        return cursoRepository.delete(idCurso);
    }

    /**
     * Buscar por dia y turno
     * @param dia -> dia por el cual se filtra
     * @param Turno -> turno por el cual se filtra
     * @return -> el listado de cursos filtrados por dia y turno
     * @throws SQLException
     */
    public List<Curso> buscarCursoPorDiaYTurno(Dia dia, Turno Turno) throws SQLException{
        return cursoRepository.findByDiaAndTurno(dia, Turno);
    }
}
