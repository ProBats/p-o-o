package ar.org.centro8.java.curso.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ar.org.centro8.java.curso.models.entities.Alumno;
import ar.org.centro8.java.curso.models.entities.Curso;
import ar.org.centro8.java.curso.services.AlumnoService;
import ar.org.centro8.java.curso.services.CursoService;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class AlumnoController {
    //Inyectamos los servicios, no los repositorios directamente.
    //El controladores delega la logica de negocios a los servicios.
    private final AlumnoService alumnoService;
    private final CursoService cursoService;

    //el constructor completo genera la inyeccion de dependencias
    //Spring inyectara automaticamente las instacioas de AlumnoService y CursoService

    @GetMapping("/") //anotacion de Spring MVC que indica que el metodo se ejecutara cuando el navegador haga peticion del tipo GET a la raiz del sitio (/)
                     // Una peticion del tipo GET es cuando el navegador pide una pagina o recurso.
                     //La raiz (/) es la direccion base del sitio, sin ninguna ruta adicional en la pagina principal se ejecutara este metodo
                     //El metodo se llama "home" podria llamarse con cualquier nombre, generalmente: "inicio","bienvenido","principal"
                     //Por convencion se suele llamar home porque representa la pagina principal del sitio.
                     //Para este proyecto utilizaremos la vista de los alumnos como home para mostrar el funcionamiento completo del jdbc
    public String home(Model model){
        //el String que retorna sera el nombre de la vista a renderizar.
        //renderizar significa transformar datos o instrucciones en algo visible en la pantalla
        //En este caso, renderizar es construir la pagina completa con los datos que le damos y mostrarla en el navegador
        //Model es una interfaz de Spring MVC que representa un conjunto de atributos generados como key-value que vive solo durante peticion actual
        //Es un conjunto que Spring inyecta para que el controlador envie lso datos a la vista.
        try {
            //delega la obtencion de alumnos al servicio
            List<Alumno> alumnos = alumnoService.obtenerTodosLosAlumnos();
            model.addAttribute("alumnos", alumnos); // los parametros son key -> alumnos y value -> que seria alumnos, la llave es la clave con la que la vista buscara el dato y el valor es el objeto real que se quiere exponer. La vista utiliza $(key) para obtener el dato real
                                                    //Vamos a cargar tambien los cursos para la busqueda
            List<Curso> cursos=cursoService.obtenerTodosLosCursos();
            model.addAttribute("cursos", cursos);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar los alumnos: " + e.getMessage());
        } catch (Exception e){
            e.printStackTrace();
            model.addAttribute("error","Ha ocurrido un error inesperado: " + e.getMessage());
        }
        return "index";
    }

    //metodo para mostrar el formulario de alta de un nuevo alumno.
    @GetMapping("/alumno/alta")
    public String altaAlumnoForm(Model model){
        model.addAttribute("alumno", new Alumno());
        try {
            List<Curso> cursos = cursoService.obtenerTodosLosCursos();
            model.addAttribute("cursos", cursos);
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorCursos","Error al cargar los cursos: " + e.getMessage());
        }
        return "alumno-alta";
    }
}
