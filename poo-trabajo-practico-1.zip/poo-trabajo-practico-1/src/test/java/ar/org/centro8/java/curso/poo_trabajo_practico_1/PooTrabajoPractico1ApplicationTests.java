package ar.org.centro8.java.curso.poo_trabajo_practico_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooTrabajoPractico1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
