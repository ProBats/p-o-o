package ar.org.centro8.java.curso.poo_trabajo_practico_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooTrabajoPractico1Application {

	public static void main(String[] args) {
		SpringApplication.run(PooTrabajoPractico1Application.class, args);
	}

}
