package ar.org.centro8.java.curso.models.entities.enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
