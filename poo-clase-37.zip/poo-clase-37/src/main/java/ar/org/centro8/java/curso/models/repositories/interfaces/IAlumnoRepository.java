package ar.org.centro8.java.curso.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.models.entities.Alumno;

public interface IAlumnoRepository {
    //estos métodos podrían lanzar una SQLException que es una checked exception, por lo tanto,
    //el compilador nos obliga a que capturemos o declaremos la exception

    /**
     * Método para crear un nuevo alumno en la base. Recibe un objeto de la clase Alumno.
     * Y lo guarda como un registro en la base.
     */
    void create(Alumno alumno) throws SQLException;

    /*
     * Método que busca un Alumno por su id. Se pasa como parámetro un id y retorna un objeto
     * de Alumno.
     */
    Alumno findById(int id) throws SQLException;

    /**
     * Método que retorna una lista de todos los alumnos.
     */
    List<Alumno> findAll() throws SQLException;

    /*
     * Método que actualiza un alumno. Recibe un objeto de Alumno y actualiza su información en la base.
     */
    int update(Alumno alumno) throws SQLException;

    /**
     * Método para eliminar un registro de alumno. Recibe un id del alumno como parámetro y elimina
     * el registro en la base.
     */
    int delete(int id) throws SQLException;

    /**
     * Método que retorna una lista de alumnos que sean de un curso determinado.
     * El parámetro que recibe es el id del curso.
     */
    List<Alumno> findByCurso(int idCurso) throws SQLException;
}

// CRUD
// Create Read Update Delete 
// representa las 4 operaciones básicas de crear, leer, actulizar y borrar 