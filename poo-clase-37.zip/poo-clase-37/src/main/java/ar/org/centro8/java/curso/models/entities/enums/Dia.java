package ar.org.centro8.java.curso.models.entities.enums;

//eNUM ES UN TIPO DE ESPECIAL DE CLASE EN jAVA QUE DEFINE UN CONJUNTO FIJO DE CONSTANTES CON NOMBRE
//Se utiliza para representar valores limitados y conocidos de antemano (dias de la semana, estados
//de una orden, tipos de usuarios, etc)
public enum Dia {
LUNES,
MARTES,
MIERCOLES,
JUEVES,
VIERNES
}
/*
 * Un enum es como lista de opciones fijas. En vez de pasar el texto "LUNES", se usa Dia. LUNES
 * y Java impide poner cualquier otro valor que no existe en esa lista.
 * Cada valor dentro del enum representa una constante, que reflejan una instancia de la clase Enum,
 * Estos objetos, pueden poseer atributos, para ello debe crearse un constructor privado que le 
 * permita asignar el valor como estado. Es privado para que desde fuera no se puedan crear mas
 * objetos del enum. Al declara los objetos dentro del enum, se le pasan los parametros como valores de sus atributos
 * Implementan Comparable.
 * No pueden extender otra clase, pero pueden implementar interfaces.
 * Se puede sobreescribir el metodo toString() si quiere representar otro texto distinto al name().
 */
